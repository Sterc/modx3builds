<?php
/**
 * @package modx
 */
/**
 * @package modx
 */
class modAccessibleSimpleObject extends modAccessibleObject {}