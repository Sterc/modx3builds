<?php
/**
 * @package modx
 */
/**
 * Defines an access control policy between a principal and a modMenu.
 *
 * @package modx
 */
class modAccessMenu extends modAccess {}