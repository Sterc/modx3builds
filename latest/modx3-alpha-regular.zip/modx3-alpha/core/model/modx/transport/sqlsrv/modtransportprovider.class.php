<?php
/**
 * @package modx
 * @subpackage transport.sqlsrv
 */
require_once (dirname(__DIR__) . '/modtransportprovider.class.php');
/**
 * @package modx
 * @subpackage sqlsrv
 */
class modTransportProvider_sqlsrv extends modTransportProvider {
}
