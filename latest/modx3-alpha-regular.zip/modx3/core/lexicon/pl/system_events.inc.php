<?php
/**
 * System Events English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Wyczyść';
$_lang['error_log'] = 'Dziennik Błędów';
$_lang['error_log_desc'] = 'Tu znajduje się dziennik błędów systemu MODX Revolution:';
$_lang['error_log_download'] = 'Pobierz Dziennik Błędów ([[+size]])';
$_lang['error_log_too_large'] = 'Dziennik błędów w <em>[[+name]]</em> jest za duży, aby go zobaczyć. Możesz go pobrać za pomocą przycisku poniżej.';
$_lang['system_events'] = 'Zdarzenia systemowe';
$_lang['priority'] = 'Priorytet';