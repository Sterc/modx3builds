<?php
/**
 * Mail English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['mail_err_address_ns'] = 'Należy podać adres e-mail do wysyłki.';
$_lang['mail_err_derive_getmailer'] = 'Próba wywołania funkcji abstrakcyjnej _getMailer() w klasie modMail. Ta funkcja musi implementować w pochodną modMail.';
$_lang['mail_err_attr_nv'] = '[[+attr]] nie jest prawidłowym atrybutem PHPMailer i jest ignorowane przez wdrożenie.';
$_lang['mail_err_unset_spec'] = 'modPHPMailer does not support unsetting specific addresses. Use reset() to clear all recipients and add back the ones you want to send to.';