<?php

$_lang['language_pl'] = 'Polski';
