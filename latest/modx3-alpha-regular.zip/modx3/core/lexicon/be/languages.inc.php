<?php

$_lang['language_be'] = 'Беларуская мова';
