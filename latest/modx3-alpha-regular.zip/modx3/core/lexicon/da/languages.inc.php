<?php

$_lang['language_da'] = 'Dansk';
