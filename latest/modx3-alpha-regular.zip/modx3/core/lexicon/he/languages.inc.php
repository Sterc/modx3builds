<?php

$_lang['language_he'] = 'עברית';
