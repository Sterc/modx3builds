<?php

$_lang['language_ja'] = '日本語 (にほんご)';
