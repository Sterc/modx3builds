<?php
/**
 * Mail English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['mail_err_address_ns'] = '送信先のメールアドレスが必要です。';
$_lang['mail_err_derive_getmailer'] = 'modMailクラスの抽象メソッド_getMailer（） のコールを試みます。modMailクラスの派生クラスでは、このメソッドを実装する必要があります。';
$_lang['mail_err_attr_nv'] = '[[+attr]] は有効なPHPMailerの属性ではないため、実装によって無視されます。';
$_lang['mail_err_unset_spec'] = 'modPHPMailerは個別のアドレスのアンセットをサポートしていません。reset（） を使用して全ての送信先を削除し、再度送信先を追加してください。';