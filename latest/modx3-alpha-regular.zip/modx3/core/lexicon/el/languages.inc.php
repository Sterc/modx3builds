<?php

$_lang['language_el'] = 'Ελληνικά';
