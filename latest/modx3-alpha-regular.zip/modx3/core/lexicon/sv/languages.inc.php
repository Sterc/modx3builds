<?php

$_lang['language_sv'] = 'Svenska';
