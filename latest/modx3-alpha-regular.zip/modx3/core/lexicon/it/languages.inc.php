<?php

$_lang['language_it'] = 'Italiano';
