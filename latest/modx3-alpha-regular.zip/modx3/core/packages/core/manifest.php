<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '066540adf910a2f822f3d559030c26ae',
      'native_key' => 'core',
      'filename' => 'modNamespace/772026d41e1506c4f3fa56c336414075.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'b73ccb37b5d93ecaf5f0a4ead51c832a',
      'native_key' => 1,
      'filename' => 'modWorkspace/51017c9220940401efc109fd823c7ee7.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '389479b88bb3093b1fef298333f2562b',
      'native_key' => 1,
      'filename' => 'modTransportProvider/0443ebef51ff96276bcd573aa72b0562.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e77499180d56f5ea1a7758b0554c2e13',
      'native_key' => 'topnav',
      'filename' => 'modMenu/c67b75d68b7cf1ea14c7ff5065c1016d.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6c316105fd3ed915668c660cc17af46e',
      'native_key' => 'usernav',
      'filename' => 'modMenu/7d32fa3375ce23c2a6df23646e5e9cb7.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '546e215e4a01cc4e232f3b43aa93d870',
      'native_key' => 1,
      'filename' => 'modContentType/28dea58a53d898411866f7379f1b8f55.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '3f6e9548a51b9d383196f3feb708c353',
      'native_key' => 2,
      'filename' => 'modContentType/93e4b2b673775e34afa7f7b5e342b61c.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'ce93357501731cfa6c428fd43934c248',
      'native_key' => 3,
      'filename' => 'modContentType/07b98507db29dbc496c57fc08aec2b88.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '041443753ede832e86f7b517e7775fbd',
      'native_key' => 4,
      'filename' => 'modContentType/a58a3174ba6d09f0bb23301842654562.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f5855d5cc1d7b3c536d256748f52e457',
      'native_key' => 5,
      'filename' => 'modContentType/7e36493e6cc2618d2a2582127464fdb1.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f3fcf9a9eb26cbb127df5d950f5ae0eb',
      'native_key' => 6,
      'filename' => 'modContentType/ff5a8ae3afb34c137767921bb53f91d8.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '52d17f0d1ae77dd10fea81b6368e9ffa',
      'native_key' => 7,
      'filename' => 'modContentType/2b097a768b75f410d6d948ae3aaa9c10.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a6bf33c31f58f5890f2c230f8d14a04a',
      'native_key' => 8,
      'filename' => 'modContentType/5d707c9c871cae4fe298df9796b34ece.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '15c4f7843fba15a18837fd91c475af48',
      'native_key' => NULL,
      'filename' => 'modClassMap/2e79b7629205e85b6c912f3649afb2e2.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5191ff340a5b4b4a1a4532f5498c0d8d',
      'native_key' => NULL,
      'filename' => 'modClassMap/d78c6d962b6f9514a7f1d54ab18d5918.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '69750864f5e0f57785614e1ca7a6976a',
      'native_key' => NULL,
      'filename' => 'modClassMap/a3aa8876a910b17e7ab86793e2c4bdee.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2962249f8ee67ff138b920a2fa3b5e39',
      'native_key' => NULL,
      'filename' => 'modClassMap/db64bb1006a37b608bf5347a23355f1e.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '283b13b7f5959d0ee8389329ec64653a',
      'native_key' => NULL,
      'filename' => 'modClassMap/6c7eff28d177363a4b732301209e229a.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4857228cf38e1c3dac95d4632197475a',
      'native_key' => NULL,
      'filename' => 'modClassMap/70a8610f0444cfa79faca8eb2349e7ad.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '0b59d154628e13904ef367b19d12cab1',
      'native_key' => NULL,
      'filename' => 'modClassMap/b0b827e8e78cc37635c89647ba445e1e.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5abedab4152da0452144aecfc1bc9cff',
      'native_key' => NULL,
      'filename' => 'modClassMap/6d1f2aef1da0080f381586dcb56feff6.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e0790fd46b9ed659660fe023386021b4',
      'native_key' => NULL,
      'filename' => 'modClassMap/9238e49244944396383ee27e475f45bd.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ba9fa5c65733f6e3c4fb0ac54d24723',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/57f4caa8be5ea125fe656e6045bea38e.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '62d7e5c568d021a92fa65a7fd30ab01f',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/e8646dff89c3c48fffdc82d9ac7236e8.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1ce01d96b53cc669637636b107d64aa',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/205d29cf8efeba32ffc63c5b4a85efd2.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '12e60ceed38af3888c3fe099926c9525',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/e4e933794144968a6473a2108d491220.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47491ce67098845bda9fab8502a90c4f',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/fdc753b738a293a58823ce9900e6a48c.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd22cad4e77d59072e35a6f2692131ce',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/bc70c3c1975fd39b5b747fe138d17099.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba89f0ce34bbf24fb9a26033ab3c90de',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/cba615e1e1a891c1bc26274787fe7984.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2da166f2b92cf5625694ba1b0ce12f89',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/bb3705ce334eb12d3b18f8f63dd2a70c.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53180bee7746c84da444ad49bd0bb4d7',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/2962a0dec49ffa5ac97d41cd380b0f1e.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ede1bcf304e14509197e79588169c32d',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/02e8ffbe45d69d1180de9f177fa2fbe6.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0bb8d600a937decc619326c4fc26224c',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/2448f6c8252af00d60038c08605900cc.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '92f4290465da1c056b2a4517b9b8bc0f',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/31b5e47e993d3a2cd34f44e35069f056.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b404c7ee9a76d49ccbf88eba62a0848a',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/d0f19f9c9af8f1cbf69730eefb06461b.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1fcf4168dab83776b561ac4a83cb57d3',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/6ce901e0e8e283572618b1cd6c4917ee.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71ce6d20c5bc5d60ab20dca7db3b4b66',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/5855d5cc9c4d2cbf05badfe808dc4d4c.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f0305a23536d4088435af19ea380b22',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/9fe61a6783736bb60549ebc5db4a9864.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '701b403cafecd3de9ebccd08dba092a2',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/cdb7f36fad4708be628f7febac236a3b.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17ad9aea9877a9907b73b4028c88d659',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/3c4678118063837db51e465231b5e392.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4c9e98a1f1efa3171a5e9bd6b2e4c08',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/2ee51bc615e50466b8adf8265b8aef5f.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '263bb7c12fceb3d16e5540d409757db0',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/3b1c5a562536bbf4e7dd1e5ba4f168fe.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b033da296b05903c86a6db66f7ee321',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/a19a170aec54809d7fd2317e04a0ba23.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '976c27d2c0cdae994046d8496b93a898',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/16f1dc6fabced6f1e2449b176d1e2528.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a133962baedb2749181f6804c1c3ec4',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/21c976a8854a509b1658bfd5b4c3a910.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '450aeb93036ac3b38a57879bc96e6f28',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/8f3dbf935f8578f9e24a346e0831192a.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20e16d3209da7947991b25aa62f94aea',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/503cc334640792c093fb2a0fd2bd3dc0.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4944089bb39b6c641eab3d5002a9ee1d',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/b3e6634446539b229e002769b402b1bc.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4602045c96ec8560a662ce015cd6fe99',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/9397df2eec5f721624d1b1210473594b.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '450afb3f28952d6fa518007c332da8e3',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/844b421614b3dfd312e2e76aff821c87.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7cd04ee7d4e9eb92d131427611fdae96',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/83320d2ac819faa2a59e16ff851f2bdc.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cedfa78e06d84b5fdb508210cf0a7fa4',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/04c1320b3035e92d2c105866370ce923.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb9c1200b6d9fcaf1661731c7a467d1e',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/b55af6b771fbb2151522220fa81039c2.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6378ac8ccf9afa92f2f76181f7009f10',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/d5d5b7422dc4c9103d2a36cb2ae717da.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa600cdd0239712f51a0b8a616cb6b10',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/e60b7de4668e5d371d7968753ed9c61a.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b65ed82a84c1ccf5e586b16df1d906b9',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/bec2c93d73df03448286dce04526ab74.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c03527ad33bb0f7fd29ac309f291f3e',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/438357758bba70a0a01446cc648e6418.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9cbd7b82a5023b6d6ef8d886b39ee505',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/42e8ff74b777d5c1fb18a59ba764fb01.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d74c7cf6a4dde74475d711a57230df6',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/f96bd81b82fd851318f706ad02e39b48.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f90335f4636c653c2af7c42de7caf00d',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/88f1de08a4bf66f5152c555160ef5c9d.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9e613bad68b08fa552db0e86a589a5f',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/8bfc697a2f51eca436812abeb2351057.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8be8c789aeeb2e052f6631baad48b93',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/8a06c7296691f17c94ab274d43c46ce8.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cdd4ca43b63814b1779d6575999c6475',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/81291ff53d19c6f3999083ddbcf161b8.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8909d54a38a907011fdbd2d24632c42e',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/be00f086bb635c0d9b935b57a4bb4134.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f7156349be3e57a1884ed349188d801',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/ce3049b668937cd5fdb8339b78c54b2f.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b98f31f9cd28e52f4bb023075bb6803',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/04ad7cdb65ec3042ce8190374e3c4c7d.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4057c01f6fd3be1aee2bf3f6338513e0',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/a634c31ca7b87e26d0b7fa919afc4508.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c673e60af7a0369fc9c26b62b454d802',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/b79d3d822c8f767cbaf088afba2c0e9d.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ab8f3186dd117cf1996fee852ba1073',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/4c007aa657298d4944e9d979f933b44c.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d10958d781e3bef9e133e1201b3602d',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/99f551f3426be1f260a6e36af19c5225.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f703a684b158ce77b373e60741b59c77',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/dbcca1f1e6ce371b9a65226f4a5f5388.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '066f2d7de9e346d724bb8f83a0952547',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/6580215523617e4dae7af49febdc135e.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88bced321d0cdfbb3673945f1d4673c9',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/2e0c4df9a93e71d3bc430bcebd6fbce8.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40146d932dab2e6aff5aa31a3ee65a0e',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/804f70743f21f41ffe21f1a0aa188aa8.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '664d21a1c9ddf7f8d41b8b5a422e2140',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/e3446822bea15dfdad9286cc2b7eb629.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '592e8f1f5f96a228daf28d9a65b0fdaa',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/cb4e356128c6341aefc9cb8f08b231b5.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8bd538aa0dac7e09580dfea85d7a8b6',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/467e4e330399656023437f2bb106f309.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '076b75f12f71c9c0a2f4feef893265b3',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/49281d2ebab3b3126cb27c1669f982bb.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2e9ccb69523f7cb0de0af22fdd10cbb',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/7acae43fb30d4557b09916b4e25ea307.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '934345c36318830c77e8a4f742aa59c9',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/9a12d1dd7418b7edceb50f1f1c2643c7.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94f8ba1ffa165bbdf0cc8b55eb68360b',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/ae34ff7c69e2766b0cc6cc854a9a0638.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'adb6955e596e77d71702116036901b6a',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/83186f884cceb1e3ea93b4ff441d88ed.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c28572dc3a887a993fe279de0e821a4',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/c3963f7034804df9604bb8c81a6b79b3.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b6cbd9458b7f7f9e602171edbce36a1',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/f527bf14b3d07fb5d747037de2c905f1.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07009be9bb23f556449b6252ca864389',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/ec89494ef879e0143f052b7d24180ff1.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7228e8399f88a3e1b66db3eb8e720a7b',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/7fa27cdc005cfaa8847346de1b6b0c37.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29edc5d7b3f30f160c70ae38e0b242a5',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/15c0a45af0a2205cb94a7a42715fa71b.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d041791bfdbc0453e6fad870c4bcea3',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/db29d3ec696bac6f758b0876410e20fb.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4fa9694fde1faf226d8a02c27ff22fd',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/a327d97662c658b69450fa73edb5d8e3.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '61149dba65a845af5343a0e2b04602ed',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/ea4a8884f0851a423055dab2af642927.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3883500baeced2c926146e0e4a5cb77f',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/2c29ebf6ef2fd4621f43fe674364d739.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89b4cdab3f5b41e0b51df647df07c7e2',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/832688dbec6539485dd2e993a0968cb2.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6408185b5b622bb9b70910a3287b7022',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/490206fe97f406ef567535caff4e75ec.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '657aff2f7a61f4b93015405788a7dc51',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/644e580113b43697029890682b15ffb9.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb67f41cd4c374b5a2a90260aa0f9c35',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/cb2b96a27b21da3a7abc87a1b387046e.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d8630020f9ffb0910038f1c2fa6a6e3',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/1ce61acf412883c92f2c5a2993fd913a.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74b57231e4aaeccf60f4c8db67292b83',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/2db05ced136e1dc31b22b672de58dbe6.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25580ab1e3a3766f7901c8b1669e3ad6',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/84c2a347412364141346d1b379d36dcf.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2fc5d02fdaa0e7b0bf13f6378d887b8',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/84a4c573fc8a7b2795cd19affbcd00f9.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a33752d614f8d63dda94a3af6206d0f5',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/db908cc6cfeafbb0bf727f39a2a4d43e.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c68d0bfef2e816f2143a8190a5d1a70',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/8dbe6f9b15f680c4b48196e1a8e70a12.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '931944551154b28353c6d871a294cf63',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/ac174512173ffa18613924b4693b5ee1.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a573b098c6025a51a3c6d92371a5c78c',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/17fb65c7758470d340824ddc0aad911c.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'daefcee5902c30592ac82c2106f183c5',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/b1cf612616117466aea97328a9a27e1a.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68a823e8bc36aa64fae83a2bed9b0164',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/6dfd1c6679098af21cfa944df973aec8.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '089070b2a578cc8b7b9b0a5a72525489',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/cea122928187ebb15e6c0b9b57ef3585.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbef4a3cbe549d46e29de5b5b1656d68',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/798a89bb82cad9205127aec3b467bce7.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca63d004d0672470b6ab29683d0aaa99',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/81c0c51afd2c7fac7d4714d1a608658e.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfb7f75362d2c99ec43d561f00ddbe7e',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/a29135e4c0f616544eb00ce8d807816b.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7e2760b377a928c9994c31bcf300fd0',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/535ef7505a2b153cb4044edb25062dcf.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9973c1c7096deca34db2da6822fc7ebc',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/cde97963b410016d804acbbc159f5629.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0a1f9df45c0c78ac92c9fdcc18cb0fa',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/773ca82f121c6b0bf7caa0f2f4bfcd24.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d15e861ec066f7a2eaa10fe1ff47c57',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/f6fc2f39eb28d0680d343b74c132f93d.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03e3e21c13387bafe9bdb69830127db1',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/d34d61f70ecd730cf01adc3379f5dcac.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac6242da81ff5b5e7894a02b9c8c624b',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/506a2695ae12938eaa90a2b02958f63a.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f11f56bdcc02a89717367cc30297ea8f',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/3532527dc238dc011743ad4d38238eb0.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e806fb9f595621a02d8299d30787422',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/a8f9bf375a1fbbf5ea95c2d067e445ed.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5affe6d75306b9a7ab6266d53e5328b',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/c93497a383aac62d75e9655b8a0e951b.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '077e2574cd4ca31725edd845e247fea9',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/4f258f1ceaeb624a9ecd3e4ed1c25738.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6008ad07e6a9193e9514ec918e67987e',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/f86ea95f10ac13f1da6a60b33402ff4e.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '948eb1e9f36ddad25da418003f89b526',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/c61a37fef84535ac976133c34767dc56.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19902065c1e2c736bfd3e2efd413ae2a',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/96b03ae50ab9ff0a0964a02a2eefa6c0.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b0f6b8094281b60c72824c870dd9d83',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/1df5d446360ba21d0dce3f65c1cdc61b.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2471d17ebb1744835b63bac9f353070',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/81dacb61daa3e28a3e29a5e412dfb80a.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca29ea2926ecb016012a6233ef77766b',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/dcbb135531b73c629fb98509b49b32fd.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7bea3d34df3e47aeaf08b292bf3b9d2b',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/cc190269ebbac59e6fe793532d03db6f.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9895f02b03c4e320733e5442cb8d005a',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/648bdd213f2a6d05c5fe9fcdcf01e50f.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40b1df6cec56b9cff5760b5ed286ed5e',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/cd3e56e5df247cc2f1df1c8ed1d93ac8.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69fb10088c20f8358c5f88ad42fe1603',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/c522a08122c48a53f04e1f27ecee8334.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23c5342485552b0c006772b11da76d12',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/3125f28bbe9f3351efe12943fb0c811b.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a5060723cb1805f3a8c8286c4a5cb718',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/458aef66d4c4d2965723cea3368e7507.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91d3906fbf80b5548522167b2eb48941',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/399a00411a108cb3e9deeda44b78b025.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4082fc13cdabdf7111576ac37f7a99e5',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/5a7e85e3af2e934a2d258e1d9b8f74a5.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cc0ad26b77de7b08b2b81343b43429d3',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/ad5a51ce5e62d8671fc7cdd15fe49eae.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9f9de599747b543ad59351f2ee48f56',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/22630f28f04e29480a2e85ad7a558324.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9101f822e22a2ad87df35156520030a',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/46caeb2d13b81d6aee4930ac54fd86de.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e076ed7b5e0d8a7d8a5f31c4e7951d24',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'modEvent/ad565a5eb21254a32465c941c3b72e35.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a66c196706d83ba883769f4df92f29f7',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/24f016a0944f723fb1f2ecdcbe3c4296.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa716f3b643da1dd76fb1996ba66a1ee',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/d80931043b177408ca88a59311e29597.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1b82a10ff8cf8e9f2d3f92490e850b6',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/c140fc9632818eda3a6ec728416b6593.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59a86801ab8ee881f33120bc3220b75d',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/9d7fd4cf3d6762181b8e3f99c8a839a8.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d9f198dc09e5c7522f8b4da11fd2b03',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/aba4e908624d698af7d05929f68617ae.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75aa8e74cd1f8314b75a974273fde8d9',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/dd64dc5cbe0ac175dc2482df4eb4896e.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b47645b3a9227998038d67089ed5117',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/2e2775047b8f00b8ccfaabf69048783b.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7650e416470cac69d3d507dff3832ec6',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/393d8d73c2f27d5e805b6c3c8b6b7467.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '163fc5503092d6677bf97ccc732564ce',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/296cc25083bc9433e8bc8e66081080af.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37348d193b4a2a85d4ac31fc0b217c10',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/9b51a30c86f05afef9ae4f0efea77cc6.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41a3fbd68d0639488e903bc04f741de5',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/c3cea2c04b504a129432fd509acccd06.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ddcb6659fe1df5ee1d7e115c05ff4ff',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/d040a78776e6530d07ce4c52cf4e3ac2.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a4447d364b562801e0795534325f81e',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/802b032c2d0e3f4e15098b68a5bf5955.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70fe5abd5b9f230c1b043aac4d03906b',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/dd03d58a49b076793c4cc6f6d19d1d86.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6da78a6081134c185759c1ae09fe71cc',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/58f54fe7b685a135356edf3e2652c35e.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35072d26c0032e196b2f8c1ab16e260f',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/24dd02398923d165452d9a5c5cbe9c77.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a522f3bf620a56ebae3585dec1079306',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/9a6f43b5bec7f679c3b3841a1316eca4.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7983899e78e2418aaf48c00499339dca',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/d3eb24e8bd555cc706a5a56b9bb4fc93.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efd9bb89e8f6733e8a18a5f48fe04d2b',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/2cac5eafec19f8d12a39ff10b46b160a.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3095aa9a360b87b41f91ac772210a038',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/587ad27f31609a20414bb426ec158c94.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dec8ec4e205369b88921d5f0fbe3f59d',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/5f9fb004d44483c758caeec2013a58da.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf69a3e02b79f4beaf7961f782cb1be7',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/38e7ba366e7d5cb277a57d6bc40a01f3.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67680bd62082df4e88b443e67b6416dc',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/0a0cc053ee55ca048c92cf7091f14117.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38bd46070b34f0c69353d37eaa9ca9ec',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/95c4c721aa788a70b2f1875ad9d9d061.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf4a893d14017a2738cdce344f5e68c9',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/529494ed0a785c4b548223dcb3ba7b64.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08eadac7e0e0a74e2d8618ed286613e2',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/3ee508f1bffbcb35cedfcb6da31e1ea6.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5ea29477e0c57663d03333787f980cca',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/c6081f169172b811e3a14fdf4b7c528f.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d368a6ca3ebc853b84ab9d12f64bda4',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/5ecf41f0dce17afbb96553a832a7a762.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2662ffd45549008b5b02197d9b604d57',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/214a7b8b36710119dc394d69d23ca121.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f1c3899093fd129c50eb993c6f9a5209',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/2519566828598b10070749be401683ef.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cdd51ebbec90cba0656ec9bc0aa78158',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/335f96bead2bf41f252858b04e0e262f.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e45ef49698b3b540155950d83a991166',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/484dd283b7fbb9b8f676d1c1b6b5ec93.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a5d67fda398301b52efdb0e0e8319b0',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/3142f481c5ab039d9d4dd4346042955d.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9439a10d5a29562c5554c175cbba165d',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/5e41cc4442050beeac3cc37473bfacef.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93d29b2af12f36e7bfbe234716eaa1df',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/d7f4e2af78e8c7d9596fae6c0adc76dd.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8c0698b4201babd32f53a7ab24f84d3',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/c019a7c64380326b490ead910fb14445.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a21e596baf358da2b3ff4416e3ca128',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/24f4e4bf46d3187c7c18922ffb8a6da5.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e07ffec3dc4d0b0af4825512eb1f35a',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/e3e64809f7413983a6c8b33765ee22ab.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab9fafb109e2c68d436868a22f40dcfe',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/4da36aa46eb3c486e8938a8ad01fd9ff.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd25f5bd196b4a2c80b6fd4f99f3ca8d',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/d4918e877f1a58e8eca0e7b5558c267e.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e237083075d2956f0d68d3ba719ee566',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/8b174cf08e015851a3020b6fa858e630.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '913bfb83646322fb8620c33a5dab1931',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/da9c2abd98f55bd0e1bd002fe1464d6c.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88c1005ca9904853a7de72f4d97a1a9b',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/c505a549a57b8001a66dc68b792169f7.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e814abab5818633facc1b1b5d65399d8',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/cdf0f50d0899a75b43eac4495f2fb9d1.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '612f9d26d491f4e79132b53dd1a8669d',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/c8cb468313f2a86c4f6f83c310581ef3.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56dba0672fd64787bc243d533adf5834',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/790714443d95e7d2be7f0bb429d02081.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36cd6e3854bdee22942889d2fc11b1d2',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/288ec147e446cd5d2ff940c1528a6f9a.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac70750d01d5069f942f0490ef00a237',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/84e9b896218a1f11e0adc1487705227c.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d1f86b9a6ed75653a3408064399282d',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/1c15d9d74ce400c9e40732df856f5b21.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1205bda9509563ef4e2696c738d4763a',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/fe970b8f267c928454adb2736a53d6c4.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a14c0430b68afe7f38de444d1ad2dd4f',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/134a00af94fada48e8e4082f831e7e75.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efe3aaaf24e400bea16f5503951d3eb0',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/e9970c9127ffaba186ef86eb2021e762.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aefdcfa671f739564556beb1007ef05e',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/ec63e53f042048ab12561050a0ff4c2c.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06fbc2d6d4edd7476637648db25651a2',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/95278e94037a2562eb66d381f781f80a.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb46fcf593801ef16b932b2a34e4a96d',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/c6c3898c8d774240964f717f644d2787.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93a5c35d0ee8c06637b55176ecb5099e',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/4348d7a98afca19970392c140e09367d.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33fa7ccbe9208eedf5049710a1440427',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/9a37be6587847a99e55573beb4418b06.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb7ad18e48506f99b3ed90b190b6b0c4',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/20da22c968075de7d4daf5ba68bc5219.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '394d4cd87c684912a6dc39062f90dc7a',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/d8cc6cf685500cd2b06d6b21656c4d75.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a6b5dbcd16a923cab2c78337a9e55b2',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/3e034d706c4f43c2dac3bcd5974189b4.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2b641df7481b78bce79411887b3f363',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/1d5695a470fc9bf6e64992958a7c1558.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15972a43e8856459328f8c8593e91ec7',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/f9f3fc123fb61a1fcf5b9f368779c21c.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4bca6e25d652dd05701f2f8c98143c47',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/cf1ecdd07c5e487aa3ad564acb366338.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aecac9ab1092b7ee8d182955be10443b',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/9ee30dfdab77776c0e3e441208e4db56.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f52b6b87c28bc7699782faf2ac267d6e',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/3751d09187fdacbeacd6e6fd4e4a0c28.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e479f354d99acd69823aea6246b24b3d',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/42889aa695837405c79b624b65e03e45.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e89d4cfb7bd3c59781f57e511298790a',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/ff399625a76dc063e988eefd436e2490.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a782e25c92e3ce759a9fc9ff90dc138',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/e996e82d96882d7dd9cb30c7ad1aa091.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95418e8e9be41ff3ba972415316edfff',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/9c2c50b2ecfac47bce246089133de8f3.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '62939388cfc9b393cb8292f8f5d90246',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/2cb250cf5678573316c304cc62ba8727.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b9bc5d10033e94b1e9038014b181ad0',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/d87af42db7cf6971d6117ef7027d4493.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a38a3ad118b5589c821d5e7387e6ea33',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/eb26e90fae02f9e5d00900443f5e68a3.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6109c6740d85c86d029da233075527fb',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/51894693d8342d8507e55ee1e2a814e6.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '973b0ddf0800f8e4cb8ca45eeb992585',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/1cb3604a5c18eacfcc82f48621fd85b3.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a97bb7251016dfbd8e1c1130e51a2833',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/ac3c246a4106a3ff2d7c06fed566bbb2.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14b3c9f04ad5a85690311401edfef833',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/657ada32f08693f9b2c43015755edd66.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e700248cfb08a0a5fdcd2c9182b8e029',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/ef6b4ca14e9e3fff735ce5c78cadb4f6.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '430e5b7ddc21e1667f6eea0eb320bcff',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/f4effddbf14bec85a9f5a2ecb5f901c7.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '619636f6f4734809d302cc6553ed1fe2',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/de7027efdf2f3feb27971ba3919ce3ef.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd02e1760baf38228367b1f9422425ccc',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/4754125ffcda98f70e9a1fef0bec2296.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '344e175bfb0063a495d8a402296033df',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/fa034666abdebf0945695d388e001adc.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16c5285162d4317cd55cb8dd50556ea2',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/e95c5b451033d1e76a53e65ba987c4ce.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '329f3d3ace9936bf2d91abb2eb21f975',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/c2d0c34f717e5b274cd5a3b5ec53665d.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8439171496e8cc45e79bbbfecd77b56d',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/b98e79168dd6e488f74e745e2e5a8253.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c1e4dbc185d780c7531ff5c6da13796',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/72ede3ebb3f65aa31e8dc1348504e24f.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '902fb9fd6f6115ad20a65ca6714875d6',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/897de5c65a941186b9d41dd953156979.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b66ac7eb980dc8566491891457c9a12',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/6f356b20dc9bc6ab22c77104b3cd47b9.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbbb1dfeab1f6eb71acc8de3bb7fd040',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'modSystemSetting/ef1c751309b01e1419af0f627b76abdf.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46409e537b7d89c5d915818725e23011',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/dce4593a615a0cf16aa095a8a8a0cb3f.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '579bdb0fd54181007dcbee753812c662',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/3114fd881dacb5b9a00371dbca1d1a2c.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39f59854e4848f7d29145c387e6a3340',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/5d4f3391eeba3f4bb3b231a8e180120d.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbc23b9277ad5ccce6e01dfa9e47bd52',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/f6b5e45ebd723b54f6e4cb2788330349.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3597d340523733e12c4ac60be5f19366',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/f993154efd2bc120cc32836ae4b4d580.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48924752f628e720634b9c2803ca2484',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/d9486b4f6ca95394cbd0f08e378d661f.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9db1e3735c209c4fc41971e11fe7bbe',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/b71a05484619875ebfd01d4201eb9bc0.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34a64f7cc4a55f75c84c013d83f5e7dc',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/ef973f366419ada3893f66dfb06f30ce.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83f0748842b16de6ff8fc526f0608b25',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/5313f7d5e37ece672efbd6921117917f.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac1b9c166c14358deeb5b576b28427bc',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/39ab0f1e8fbd5d428ed6e5c39b5b0868.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b94d30c37848a8c8d4d8b4b472b40a85',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/f624e00957cd125cb66bffe5a7804c38.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bb3c16c2dcfa18671c70b1629ee5bde',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/3bd251e5d51f488e65cad9e9f119f6f7.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e42cea2aecea1a894770451ad9c16cc1',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/4fe1e2ffc9027a75634859b6795c33a8.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b03102ce986d9516e20330b29c3591f5',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/f77a08784f14c53ef888f4e1a807cc81.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9b28e4b57875eb70b8e0b26f94e3656',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/40ca75df332936d15ff9d9972d13e852.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db1d86fc0a584f2a0523228992f2ae16',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/99cef2bd0d5839c22c6e5893ec4a5770.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '324022d49c7ab60081c5e085aa97bd3a',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/a263c1a29b28d1075759ec2625bb0d37.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8d194bac0ab1224a522c36662f565ce',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/e7d68ce18eb932c97b3222ded0c6bb59.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1dcf08da8bbbc68e1a30eb8bbcec2d50',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/01ba4789aa4c0727cbc9364b0d6712a3.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f240f240aa34d28f1ea2b0e2c93018f',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'modSystemSetting/dd2b33d4da8a738d9d65983161d898ab.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e93fd788e812ee2363609068e40ec292',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/c5bee0684862c1f9dd39579d98c8af9e.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95cd79d4b419ac775ef94899bc00ac08',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/f365dc79db1677f170435c0098c2f8fb.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aff5425ea61e3dbee50ed03c6229cc69',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/acba44b589d401f8f54a3b54047edb18.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab92cae991ba75b96b84d2dfd1ee0c3b',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/bdd546a9288e138c0067908b4eb6151e.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35f889a35e2bb55e3c7d82c1d09c4032',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/4a8d546e5ce1397a643deeb86c5cd7c7.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70621328699b93cccfe45f56df379869',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/45f183ea04709fee8dd77198c2a924f6.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffb68001e729cc0f9be89315fe0907b8',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/c6e800518a6c3dea4bb9df8d9b565a24.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4632bb8f2eab16e45ffdbba2ec1077d4',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/1dc56de2f6fea6130c325a4b2201156b.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0afbe0083ba5444c4130000454b5860',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/84c2bc8b0599a51b2158e1275c226bee.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0edda72d25fe9a35e21c2679a4355e9',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/b6c8eb8fb629e1c2800981b88a9ce4c6.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa253ff5bc537007f9d0e2d842431020',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/a5eca89b385e26469fd3381a484ca11d.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4cfef71dabfa99bc9cbb5dbfbfc58ee',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/bea76e0968a8ce7b1e3bf3defe058b52.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf14b65d4357551014294311160ec999',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/c03a012675f239a59a174c53a30e1438.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb35933b7d83aaa3a5c4f5d19a708e55',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/d9cbe861f506cacba50965bf3093c44c.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91947e54030c589c1071f6407ea3eeaf',
      'native_key' => 'default_media_source_type',
      'filename' => 'modSystemSetting/0a9a2a8079784615c6de3a02aab2ce52.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '375cb8997d6949a946650c59eccccfa9',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/be302295550314d455fb9164a50b9d3d.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d82cea20c507e067d3f447e2ef3e56f',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/207a016c97e12967683347271c1ba8fe.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32ff0f4b48fef9469413c5408e6ddc1a',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/4c1c75e2369dfa006175b4c0c0382c34.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63441eb66e5a8466f4ed81c2e13c4b7e',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/74a7f5e6db72339a4a2c126471d6c104.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f86bf409b1ec5d20bae7cc29b25db51',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/109dc84be14143bb9681f2bfa6260774.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5df9833a8c0493ebd8fd563f0337df60',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/ed57bfd36391c4d213d15f1980fac698.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbf7c215b0d74c9d7311783d32af4119',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/b4fc436c13176a9c2d2686abf9ef764e.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '459131d4ebba04324380b89ab6fed771',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/2843df851a0ebe15cdebc7125112d4cf.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e24a479a34b1cbcea2a84e945b6e9c57',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/e3ab722f64993b10b0b7abd55a8fc7f3.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d9a85a9ee9daa9a469b7c62822984b9',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/926ecefa9e7d103868c9af0ac77e59c6.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74bd0c7e888f41ac3b94063958bc1361',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/5fb9b76d1efa61ac1f760f966ce19d51.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '307754f0a7cb80be70fe121e0cf0d336',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/ae0f113208935a61c624346fd0fb8741.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '266aa6fcb1547e140523ffb5a1735102',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/ecbe831de2fccd92700430d7591a5156.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b17cc224d0c9c48c39f6386c1bd44bd',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/d32ce0afe2a926216141a6e7f19ecf19.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51dc83ec3f0b388fcdaa8be4ba17ebbd',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/f66682b51bcc3ec21d3fd168fa6aaaad.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dac7b9ad80692eca7ee51ecf75a41a88',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/175438528834ae66ce6486343961b1ac.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15580e450b9887c51034ee1a4e9c4713',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/543b2546941c3cb4ad35fad9922e8a3c.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e3300addbb4c9e67455360d8f41183e',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/e4216b8b4e693fb35c094c0dcaebc91d.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a11943415d9b840816ed2777136ea9d9',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/401ffc2fc4de45fb2485fbc581b15215.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9488d6876953bb499d7d88dcf0df9c01',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/002ac3f065de311a216c48b9a637ed20.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c47ca3367f890eadb1e760eb3ed27b13',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/fb734851d0055f1c36432dd1d33bcbab.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53d2bab5b5173424dcb33c9d4898d3b2',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/134792245c377a72284f72e8583ed84a.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1338b44d7187cf0920bf07f5134cb02f',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/448441ac6266face35161c65d127575b.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '883aa7a4e12515a6059dfcbc4497480f',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/5b3397ef9896d87d79ac7cb910d6517d.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cfa7304fdd9d4ca209d1c51569fefeb',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/9557c9c1199340f02b40898adfdff1da.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fba706a7ac12aa3239ba3b3b565a58b4',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/46cc3814df937fb44ef92728082ad064.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90f3d59d48ef39a2eb6bbc1dcba4683e',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/8151c01acc758c373819a0098d23871c.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b3c431e9ec08a366ca67bff7b779ace',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/cdc586b1e77d43cb90e356aa8f66f598.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cecdc95a71c0c4fee6ab4f58a82f7f1',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/91b6f7eba46a32aa9320f2fc00157947.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e1989f06cd0d8fbcea35c0a55afe2a2',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/cfa4b69a00c66a277923572ab7637824.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9709eaf45877b5fc8cda9ec84d6ffdeb',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/8f62285e6119f82ae7917b265eb5b98c.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11b606e3f4168f5f3158a36008d3ad8b',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/dba4b06fdb07311f8233b5b1e620c546.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30b837e36fa7cddb7eb90d7c64848698',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/bbd7f2b74787354e376eb7a370be87c5.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9b673c5838d89d9ebb8f3b3f367ab5b',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/0c44e8f264c68660cea92c2ac417ea2b.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cb3cb48c5f3e04c97b1d439b3dca014',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/21928e70229dc2710a41b5549d251211.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17bb22f1cb20c647b01b1112896f1a4e',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/abd63cc20209978307bbf17bb16e5c21.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf223ca8e60551139ea4e37e8261a7e7',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/da0ce6625e28c6c9d8b791b397a501b8.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57df9aa87323fbcc49dbb8a83eaeb71e',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/99e3c3b57dd1cf5dee86c9869453ec91.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0acb0b1c5519f210f92ba64dc54dde11',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/0463046ab82577513f3735c83a0e72f2.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '539ffc99a870d0862070c6f6cb2165e9',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/31796f46e57573181e670354f0a15e9d.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '337d243a1b48f95c11325796d325ea62',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/bb0aafbe0fa61ce3e44710b226c3a3bd.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1675628f487430a3ca290f62aef04b5',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/e43ceb154678509d7b37a877d019423e.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b00224be731fe8b1a8620c498630e637',
      'native_key' => 'log_deprecated',
      'filename' => 'modSystemSetting/16ac486b327b4154368f046cb1a7e170.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f584399ce34ec05be54b465937898c2',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/5267574b99fb17dc2915ce249c50d808.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '038c8bd96e7b0486616663f83af96900',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/25103ff7897f60132df6f6dd6462da74.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8669c8eb88fa9cce1839f4e5661fb98',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/1b015d5b0b1d3d154b1000cd82bf306d.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3734e5b8dea66db089ed6fe490fcb465',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/e105c6bae0b18cc7c6a7e7b8662c38f4.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6039436ae516580fa9d67309cdf890cc',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/ad295d5d52e7cf2b684af89ca023d4b9.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '087e2110a5157bfd669992ecb532fc51',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/09a180e7b09522060cb0f9d20e7bf767.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33991ae41346736e70ebe8f2bffd4604',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/c35bf1d107175309fc9d82725918e0b2.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af8b3ab451af23b0479ff5af845f475c',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/24d8321cf18d5d579934783947721a52.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f87102e5fad216bcf7bbc23d09bf6ed',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/07885ae27327a31c1aef3cc777e0f0fc.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b16a68badf0aa19b616c763982b35eb1',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/4a49f1b37dadd95c4d79f02c14cafc96.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a05b25e544561f71e257278abcd1fcd',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/0851d57ed595ae9d9a89df969a776171.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '017e5898e8b924c79f6ee308d7302c3a',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/4e97ba43b49e8b1a4f9d0a62549566a8.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de9f29dfc07a0b80de63a977f9637aca',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/04ae61340e42a533239db40ccbd0c838.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c98a18b7e84ced366e53d1ff42f73f05',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/f4996dec6bce0c472e3a82792d90a1f6.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '790bd4836cdc17c6cfbcd83e29f60815',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/47b18204d3a36ba871c6aef41ef5be8c.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37a1fae8eb1c1b14098d03c38cc492ca',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/6ced2410496de88fbd9cef777a649912.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '235849a47cd3c58d67de46766e5552e0',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/c81f2682317438ed4376114cb592ed44.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '693a4efcd6dfb91e3e6f20a2c43fa9ca',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/1b1ce943426dae4862de3209bc3edb6e.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1d4bb5ac4b9284110d5a99a3edbc308',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/b4fc1b8a943a8587bf80d175d05402cc.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9921e65296ff214d187daa6927b12a8',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/9bbea28044b103973736c779f69fcc78.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd216b76aa4a9db3e7ee89b3dc501d4b7',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/0aeb38478b05597dec5093d27251b907.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e32da923496bc23fea8fbdebf043440',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/85049e65d530ae2ea4588e4aa57f8933.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19ada143a098ffea08136a7d20a45fd7',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/51b40b33418384a292ab24a5b05fcc73.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c53decac56a5c6cd5a45da4fbbf47a0f',
      'native_key' => 'login_background_image',
      'filename' => 'modSystemSetting/4feb10802a97ad772eda133b09784149.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89071bd944755c63cd13049fff962bce',
      'native_key' => 'login_logo',
      'filename' => 'modSystemSetting/7819beec2bd1c1eb9a9daaf435707d9c.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2355e6911b069f36e52080191910ec4c',
      'native_key' => 'login_help_button',
      'filename' => 'modSystemSetting/1b5a5a6cfd2b0612b7119bbac6e7145a.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2259907c1b4dc762d11d137a859b8635',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/06de4e627f07f3c5d3aa0ad17e42913e.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3106e3cfe11a14b40f10b0563ab23f98',
      'native_key' => 'manager_logo',
      'filename' => 'modSystemSetting/cb82de42e2e97a6dbb6d2da9e146c7f8.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2318d34cb1d1141fba42d4e800e90136',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/c65e5cc91d37172cb16e5d5cadeff43a.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73399d4fcbc1a15b76dc2869915cdae1',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/9ce10388ef4609578ea49de12cf5eb67.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '674ee3067518f9d9d791b414a7862d9c',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/03f4dddb85cfa53a94125e4d1ba552b0.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '870df61884e42b4c1987d19a987834e2',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/2f1f6255a794030e2436e3f593fd8774.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b079b478491269298262957b192d766e',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/5423ef8d5a6096e801361e971390e767.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2afd86022ddd965a6a506040d74d83be',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/bbb2002169ecf05098999670ccf88e3b.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d8327516b396aa309ca5f7082999fd7',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/43f09caa82ba3f2c3a9e64d90380d6b5.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c6037d2d1e5376c3c999bb1f877bc5c',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/7261cc0064ec9aa5c6dc3a81841a2729.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e52cc65625a964e08c5a196f48e4adc',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/9868ac915a0d4eda364323cb3aac8b30.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8c717845d946b1737171c02f1dfa2af',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/ea7f2b7d1c265cb4e6e9f0c350afb0f7.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9eaf66c14c34c62444b1128afacf2d90',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/b7d873270fbba8216131d9d41df8811b.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2935780997458e9af8642192f07891be',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/2dc17952f9b35f0c6abb9959e9c0cfed.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d6e88f30aeced95133d1b8dd4358de3',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/a8780c9a93e439bcb1b784bf175a4b0c.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb3575201d0ce0edce71ba177a12eb38',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/3dbf22f01660aa6394dc3ae4c6151824.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb392b147f70aa718a4f8b2a991d69c0',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/a393a859868779081ff27b0808558699.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69f2be9a7cfa0ef8bcdbc34bbf4578e8',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/4f3749d5593314030649426761c12611.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '872451a3f4dd644201b376066c488b85',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/25d7c8f1c838537985a58ee4d4a722c6.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '973584e97e1540839f6947dbd8e2ae00',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/1697cece619128b05144608fdf81c2f2.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1a5bb4cce9a3e21055e4cac8b377ef5',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/bc77a6513f5cfec0a3f9ef7a2b7da812.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82a672c6bed190a75975d72b5a4aed52',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/a5567636c1bec2183946bcc3e13e806d.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42f3654e2f4cc333eaf62f05ecd33d84',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/03d3e337152c39b06d3dc67beb0bdde7.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '884cc8c0980f2a5cca6f71aed0de1a64',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/cbb92647e9349a7571989859f80fac76.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80d43d62068e271abdba532d7971b464',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/bce8791066cd27a847d66f30cbfb3be7.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ff7a31d8ed24e9f2f3b524fcb38198b',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/1ac2e3b82cda3df99b730459409fc77e.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1ee0454f2f93820006ee192f273696c',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/01bc40d0e1e3d3a9e331bf3ae8fc597c.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37f4da6dff547e287a0863479e207f28',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/4e4ae21b0dd053fadb276d857fa06543.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2998feb1cbde4cd458533c79b32d6895',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/64a67128b91624d266119bc632ba41c2.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9550eb230b528e09ee280d54f701b6bd',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/0dc89fff5f654c82a86310e0892828df.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c1ed9bd2f8b5b6e3497a0fcc25b650e',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/711ca39d37bf4b160b392496b695ada8.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ccbe9a55510ccbf2a54cc16410667f4',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/770c16e1c256437d67d90a68daeb8b63.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66b9d2cd475fd30ee2e4a825e0c321c6',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/48d3a3c4bc12f5c55204c27efdd323ba.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c75087c3e1e9ea02fc559c0948ad457c',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/6072579d3a95023c59f1b42b2961d7cd.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f29f7ff534c809e55bcf19f0bb04cc85',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/4af49a140aef759a59e5b3f982d34363.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afef61ee1d7c842e135b02522b163696',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/3be6068f30c8de788c1706ffff69c8ab.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c3a0ec94c2c9dab30bb2cc45763356e',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/e267ab0ca32ffd67c0cf5056ef9dd59e.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '805a6984c2d471cfef1dac8be16db3d6',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/3c9dd3ba64911f3856e8ca3c6f9a8e0b.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d3765b0db2b0c63e7f25439330044f1',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/d36b7de3701cc9a8dddbaee2cdb36fc9.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ff12e99a221846c152e1be2a5fe7088',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/b58668279dbaf7760a633fcc51ff86fc.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cea4cf47b22aa1aadb727f3734f40e37',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/74e8531f00fa6e9ede236f9e59a166b3.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ebe8aa67aba35f1b5d875bb4695266c',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/92b76ef7b4ad2f64bccdbcc3b6eb80ea.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0dce8486343b1a247eb55655daad497',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/be1c52804df341ffa5502c9e551f6b49.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3908b99d92d1f3f948ad3ae192914e20',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/934899eb62e7f83bd663271918349a55.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '878683eb4d40d5a08a76c1dd9ee44466',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/1d4c0c13e2f27223feb834c35930378a.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f0cc52a9f56dcea6fd0ae7e8f8e8114',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/e24f000e6d90959f5021069210747ba6.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41ffb6d4051957f941408e60179c49a4',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/59035252f0527a58b90eeca2c1e44b57.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22b728544412bbb4537dc18db344f578',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/3ef2496a6ccf255c2ba33aff18d72987.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b1101b49e0240a5f798019bf9b258ee',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/b39ef9540806a9da7b604803b72e6b90.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cecd22c826980fb86db8e3237864ba7a',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/6f884c69209257d59c7e01289042e7a1.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efb95e2afbad75ba1ffc99f58020c000',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/df8dd175410e809e54cb1f806d388576.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29b7d488945363e081548e8204230ac4',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/93d201b7e9436bb8012d316aa0584df2.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef9a50470bbd85fa8d0550e2e98ebbab',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/cd5b5ecb4a927b526628d99dafa1a273.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f3a8ba6a92bc06a7f44cd8fb0dc6752',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/51abcfec81d8c2ac85ef964d1c67a9d1.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4a25110037437425ce4f065a0b81ed8',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/210f67ff3a147fe9c7f39f0877ffd5fe.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd785b371f798b4e60800425487b50eed',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/06a78a854805ed49c1d088fed64e5add.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '251309309446b4dc02166b1950c95c31',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/cf7d19357fbdfa1fedaf4d436c3560ea.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d675f2b9f0bb12fd7982d4d0d563b4a',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/415d9679f412ee0104d0e99e54bd6837.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec30aced58687f9bab45844dfe71f949',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/77736133e79dc99156c235cf3842ebed.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9636e20158858524f7b67aa5a403af53',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/f062e1f573cda5c9d8fb7bc2c7bdbe02.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f45efb548a2a3033879c99ec24022d0b',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/56c45dd51b8de4902d405e732fa8c4d6.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1606b7d1ff4a1ec5ff8ce341f162b74',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/b7073caa8d1d0263c720f37e747cfd87.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '218671cef3a6de2f72eef4929c1037c0',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/2e2af9b226e9811c0fec564712034eed.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf26105217e77b7f261c72e7074d5926',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/f7ceea5002cdfcabb1d40d06ba2c1c4d.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa97dc057233018aa4e3b2924247dd01',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/1deb9b4fb6f0a13c6dbe0bd5e50477b0.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c605e4ab39d4b931cb9ad9fca9fb96c0',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/11825d11fe03d2401ce24a802f154b1d.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20d26f86b65f2a090b5edf791f30e6b3',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/f3042640b8246d67a916060bb1fa38e9.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a596f6d3ddc3f0dca98f93b2d547b96',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/db07380070cba6f7f20c55692d0acf4e.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a94d6c54b5993f1ddaf7b8f9a402178f',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/e0255e4193551ee2ad4ed42a5c0d6277.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28185203016de908e24b2c80f7fdf9da',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/e387d21819e35ea9ffa71e3817bf339f.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66a73bac5ed9c90b74c1ab1e680fa8b8',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/a7f44d5f526f720afcac25f227d47f37.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c18fab9c4703bc649d4bc42e30f430e9',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'modSystemSetting/5a0c56f7657d52f8722cd933dc4819ba.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16c64948d0a698ec15f579084a7471ea',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'modSystemSetting/c78c63881181aea2c8404bea99f78308.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8dfb62d21d80c376f77bdc0b52857201',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'modSystemSetting/da38366451f68b3873ab9e8533c656b1.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '772d64e43607c04098df14baf30e31d6',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'modSystemSetting/94f235564eebc79f089ca06d1c66bb24.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bbb389a5a96d65da847fd860a7d907b',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'modSystemSetting/c440a67d2e55620d4b5b6b4001e1ed2a.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a76f36acbbd05281024a28a2bdf6757',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'modSystemSetting/d59325bedd956da5f3c2314401f78414.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71c33c8ae83a1c9d59f191629db88733',
      'native_key' => 'static_elements_default_category',
      'filename' => 'modSystemSetting/50c47d898efbd4ac6b9eba403ca36e2f.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc85f6bd1d44b997ed1233004c8eef2c',
      'native_key' => 'static_elements_basepath',
      'filename' => 'modSystemSetting/1f5279583b9ee128535c01c3a88019f2.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5f4636d308bcd972dd2a8f863678780',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/4dbb3dc005edb72755056183ae3a2713.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '062ad093eb71b1671ad71f480fdfa294',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/fb5de40e1087fdb5cd327ec0be1b3d7d.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcbe5445e5a8357aa99c9593ae0cf138',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/335b948c744fb81ec8d39c7e01dbd629.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8fc92c62be850afcaa719d49cb6b240',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/fe20098c2bbfb8a8053750f94d7cc82b.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bf65e61e2027c82adac95860f084168',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/331b50a91439ffdbd7cde5328a967941.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da6097950b0ab4815d6ac1f869b0b575',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/cb9c08360b759dda56fb9bbf28cfe3e4.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af2f288ed0e4957395d43e84fe577ec6',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/3a0f3d1ad4033733cf18bbd44ca6b8c8.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08e7fa2126c500295daa2ea5cff454b4',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/f39ac2747ed6fef19081c78c63771752.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6da979ba78b284c24e811fd84449e1cb',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/f75f32440712cde200eb251fca670eb0.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8064166a3240a7a49638faa3f0ea2aa2',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/3082e87c86f6f62af76f4cb07a0c0960.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3497d7e6af22deee47eb10006dc3f87d',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/9e0bfc8915a810e37450d6b785befd01.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62fb58b05635fa6a97dda978ce5da9a7',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/84ef6a08ebf28a0f7255c5ebe76be0e0.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1c4166be800f9b9dc6530af8f4f6840',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/3572b5d66bd3dd854721ca1cdaf46653.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe3b22cb801762caaa92490c09096a38',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/28fde47bf1683971e4db7b79b6d34cf1.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bc2ad9cb55a11ac355337f0e9b996cc',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/066be0ca07c5f35fe68f8a3661e0403c.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71baf4fe1b8fe1fd88264452214aeee7',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/59668bcaa82e4c77ab5e9d762e3973c7.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '409fb61ec5d42dd149f55c4e991fe42b',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/7ba3df853d1362c42cfb8ec85e31670c.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dccf9d3aa6ef8588bd092fa968cb3e92',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/a7f30a767e1bb14c4fa598225acb88cb.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5421e92ef806fa427b44f95b70999dd8',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/21be5563d8e60ae8abcfadf44f61f86c.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f6325bf62bae4bdacd7c1fae2396fe6',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/d4155af22f9a5ebac29507b543b5ebc4.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e79fcfcf6f999a60dd8bf34d69c1c943',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/6fb2cf461125167c71b5b4cb0cd1c065.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cd96972610b0c842953c2fbd519c1b0',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/fecbafa4b8bf809d9520156eb07fed39.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f70d8ca93afbdb24f48cc7161470439',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/6ef452e3ec3b2a0a688c1389d610cc9f.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d4bd1f2f5f2a4001987c6a17d12dfe7',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/6891375a2ba473267e9a6be4d3e15dad.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc7c4583cf81f0119246f48c6ec1e5d2',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/e0780ed952f5e6233fe4908f8fa44eb6.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a5651375cf80191aac7446af20449ea',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/967ce78635497ecb1d6b3ed00369dc6b.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca059696f1f7da98198cdfa28cec820d',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/44cfcfd000dd02aa6b1261b35599c29d.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a20cf0eb96ec2ae04ae62b9af17292fc',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/9baace105363c5fcddbf8a28d105e0f2.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '972a36e2f35d0670edcd04a23d78e8a2',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/3ecff30dccb9524aaa0f2122ed502952.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb1c9c15b66d867ecb065ba92d2b054e',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/4db08c9a47a170cb53d7ed1f18c9f451.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91572f24dacda83419645207a4a57522',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/a5c85ad056090f45f802e2b114cd5a93.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7eb687f22dfa8f0e720b09219677ca5',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/836cbbeaa795d5b17d9d34e7882cccfa.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fb044a5a4fe38f29ca37f9f1e93d982',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/4bbc9a46cb00caad4e3ff5dd046be32b.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47ad67c96008adf730b24bf44296f5ff',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/7cc171a02d7047077d496be45955f7fb.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1007e42580e286d470f30ab8a8a17f67',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/56d981f30b7c611b9cb1f20ddfaa5235.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '197d51bb63727465e81e96f841f140d8',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/d6b1ddf4d73a817b0183bfec17a5463e.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a098adb87e8c13a3c7a4898d606bdfce',
      'native_key' => 'error_log_filename',
      'filename' => 'modSystemSetting/9f7745cae759e250decdb405031db7d8.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e27caa1b816993681785411f2b2fef7b',
      'native_key' => 'error_log_filepath',
      'filename' => 'modSystemSetting/1784bd8551bd1bcaef3b7e9b24172bd1.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad4af85b83d669de30d93918ad3a16a8',
      'native_key' => 'widget_welcome_background',
      'filename' => 'modSystemSetting/d1475a7f71acedd42e8d386340dc194e.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '4d2d0ac5a867bf951aea93bf124b3001',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/434199d7d75616100da97964c39c249a.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'bcd7311bc2a52715167c5eec32167cee',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/d52e1736eb6d72546751e75bca3dae9e.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '128f0d94799767a7b71a8aa33272a25f',
      'native_key' => 1,
      'filename' => 'modUserGroup/edb914d5cd8cd084506c844e85366265.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '540924804f4a685bfedd56a13f7f96d7',
      'native_key' => 1,
      'filename' => 'modDashboard/84fbeedfc2fd4a1c550e29ac5aed6d21.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '311df76ab1cee646c3c68e946fce4f2e',
      'native_key' => 1,
      'filename' => 'modMediaSource/abad0842dfc967f7e048aace1db3fcd0.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '6eceb20b7869b52de80f6a390ba8ff78',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/01d446b23d42fb881318df2367119b9c.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'bf063a3edefe033a5a3edae4b4f09061',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/418308151b4f3e3bfae3d3d272545772.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '7d92381847cbf2c885335cd11081c7c6',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/b97160d482c6c8b8c473332799a0a265.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '3b55cf2f8d3ba8486453d092568d6496',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/a2b92f933e9d231606af25b98814e62b.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f15da0ca64ccb0a8d9b6762e8fc1a45c',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/249b46d449400fa4aab9b3926ec128e0.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'd6fbeb3a5c22a7b0e4c083c1282977fd',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/c9e7b6065cf79a1a9a2d3c29da49ed2a.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'b91e589ae36f6658915bfd5215d52b44',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/97fa25cbbc1fcbf542cf65a2197d7df9.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '8fababd390b1cdb11ba27a0055b1691c',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/a61ab0310de5e91f8f4f1ec0a7352754.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'c8614aabddd5b43b2bbd8b04131ef8b6',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/2f14a3fb8bde2f19e5b6199ec09f96b4.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'c3c43ff15b6fb4f25612b2af34f2b470',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/ef8f33cc95893b945b4c1340a222ca1d.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'a74583d5203ab2e62fb1d7938e630de4',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/f01eb34bdbf3a429235870ad1244b311.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '424be329dc1982c90905721be1f43e52',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1cc20d42cb5fde4943b6305e61ec12d8.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'dae84470e0d456affd66b189c788d71b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/4075b31efbf29e489e58442e6b406147.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '2de49eb7a55089f15e045c14cc3bed03',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/0fac68891fe664a2ed24984b9a631892.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '023681cc14b6bee4623c9f6aec7cffa7',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d59980f66d77dc616a8eea267aeebe75.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '3b53a240c2ec41e4a07a610cfd286728',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/3798b743beb39df25a13bd61a2359dd5.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'df74fa1edb7254b189cfa440c6ae843d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/c90655c8494f45a0ebaf77b6c5f0e3cc.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '1c1da1a7e54417f6c6709a3e561ca7e5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/381c62a50c3593e9b5c9bcb4bd0db6d7.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b554db596c025e74f1ba2b295c9da3d3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/3abcc998ad0cd7463e854067d7ef3bc0.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '0e842a5e5f3f5b695111652269f924c0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1fd031ca444bb86efc7519afd54e010b.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'adc790e931ad1d674642a43d7041b048',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/df2a4562310e3de2a6e8dca2abaec3b5.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '8f3fd866d10d19be0bf4320c642f7c7c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/673221b41c74bf837db69a2b965ec37c.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6284a342a14985d9f8fc95055f23a263',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8b123c2666060d9229f71f66dbac8bff.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'e553c8d8821757344cffc725633a3217',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e15a6df053c8808bbc8c948027b65418.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1f7ce66d152059729e8e0c2c0bc64775',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/7305311c3715a9630798376c22a0522e.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '24e4c108bfca09dea7da6ebf729d3fbf',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/dbe23959b3fce7c0e6393b18f7c5c060.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9ff53b349271e33a2b7c72f5f1c723cb',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/8c8de809e3b9650e28861bc592b35860.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1cbaa412f78bcf5b8fc290bf46d47412',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/b7a8a796fb94bf74098491ac41e83f2c.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '039db6b8dc44a1e8ee317e1bed639b83',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/73800c67c3aaccdc66fd2bd6778fa503.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '78488aa86459ac554999b8306620ac98',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/9a07babae5e718a284624177ba8726c7.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '123fe8cf3a618e67deab5f540025227b',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/cf3b33fc16c4ed3a982fff1f350bfced.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9cd53fb18895fec8c5c7d82ac25f2011',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/e6f3612532578619aeb69bcdfd755883.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '57b49f5369b41b0594d339ac83418965',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/769cd28658275c5552ab690122cef695.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c81d14c01413db6ed73827a19baf6e69',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/4c54b0d55018a0727a24400d477e76ab.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '358bbe8644fd8489756f0ddaf8f33b99',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/d74e34093bda2aa1893b14ede42dbda0.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '55cab94c0d3b55d51f99717c4244d98e',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/2c1963d3b956436aceaec0afca196be4.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '6b90aa6069b3e3ad830ae12e7ccc02ca',
      'native_key' => 'web',
      'filename' => 'modContext/bb303265c400a3d1adb161ab5b61e357.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '39b21696d6052484b8ac64f3e382c57f',
      'native_key' => 'mgr',
      'filename' => 'modContext/05bd66ad239f9ade179eeaa798185c48.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '80b2219b1e1b69549c1424086f69bd71',
      'native_key' => '80b2219b1e1b69549c1424086f69bd71',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/b258c3b42c9371f21d31f84d18d03414.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '66d55362cf1c7ff20c236bbd12eedd0b',
      'native_key' => '66d55362cf1c7ff20c236bbd12eedd0b',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/145ee568415bad22c08b604a86c1b738.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'a4b6eab5d64717129c1d85af78f24d2f',
      'native_key' => 'a4b6eab5d64717129c1d85af78f24d2f',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/04a8b47a8739d00a6d617cd06556750c.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '59c63cbe4990bf2f7309ff9b3719b641',
      'native_key' => '59c63cbe4990bf2f7309ff9b3719b641',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/5c808a779e78fae2f7aa161ac90a2794.vehicle',
    ),
  ),
);