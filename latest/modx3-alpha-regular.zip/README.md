# MODX3s

This can be used for creating sites on `MODX 3`

## Versioning

To make new fork version:

1. Change value for `$f_version` in file `core/docs/version.inc.php`
2. Create new tag in git `git tag -a modx3s-1`
3. Push changes to this repo
