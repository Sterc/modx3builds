<?php
/**
 * @package modx
 * @subpackage sources.mysql
 */
require_once (dirname(__DIR__) . '/modftpmediasource.class.php');
/**
 * @package modx
 * @subpackage sources.mysql
 */
class modFTPMediaSource_mysql extends modFTPMediaSource {
}
