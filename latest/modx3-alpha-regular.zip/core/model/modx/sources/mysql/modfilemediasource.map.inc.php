<?php
/**
 * @package modx
 * @subpackage sources.mysql
 */
$xpdo_meta_map['modFileMediaSource']= array (
  'package' => 'modx.sources',
  'version' => '1.1',
  'extends' => 'modMediaSource',
  'tableMeta' => 
  array (
    'engine' => 'InnoDB',
  ),
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
