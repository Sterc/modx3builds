<?php
/**
 * @package modx
 * @subpackage sources.sqlsrv
 */
require_once (dirname(__DIR__) . '/modftpmediasource.class.php');
/**
 * @package modx
 * @subpackage sources.sqlsrv
 */
class modFTPMediaSource_sqlsrv extends modFTPMediaSource {
}
