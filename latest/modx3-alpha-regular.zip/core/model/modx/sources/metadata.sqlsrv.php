<?php

$xpdo_meta_map = array (
  'modAccess' => 
  array (
    0 => 'modAccessMediaSource',
  ),
  'modAccessibleObject' => 
  array (
    0 => 'modMediaSource',
  ),
  'modMediaSource' => 
  array (
    0 => 'modFileMediaSource',
    1 => 'modS3MediaSource',
    2 => 'modFTPMediaSource',
  ),
  'xPDOObject' => 
  array (
    0 => 'modMediaSourceContext',
    1 => 'modMediaSourceElement',
  ),
);