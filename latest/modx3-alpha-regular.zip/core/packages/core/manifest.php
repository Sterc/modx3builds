<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '78b4b1afad1894c0e4f6a571baef2998',
      'native_key' => 'core',
      'filename' => 'modNamespace/5853bfa299e336a08415eca3b905281d.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '3a0adbcb4e9ea28b9fe98ad221909c9b',
      'native_key' => 1,
      'filename' => 'modWorkspace/25e9a14bfbbf212fffc1faf31eaf528d.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '8ec2e1700fb6222b16509347143e302e',
      'native_key' => 1,
      'filename' => 'modTransportProvider/7ab8fe2e25938cc28e819f24e652d9e5.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4f199a72fc19fb9a2385a6b66189c89b',
      'native_key' => 'topnav',
      'filename' => 'modMenu/70f4fbfb645b5cadafc450f3ec807831.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e2b8e7220e1a414ee323645ab7e89586',
      'native_key' => 'usernav',
      'filename' => 'modMenu/054f4fecf37a0a2dce028cf170c5d8c5.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'd3865217bf08deef03527b78d661af52',
      'native_key' => 1,
      'filename' => 'modContentType/0a91a9bf2bd06edd174c48f5fad840ec.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b730a8e23402ed271dba00372e13a6d3',
      'native_key' => 2,
      'filename' => 'modContentType/72d58a0c6d95fbb6534a9db1b159f064.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '588abf7767e4341a24eb1328e875a16f',
      'native_key' => 3,
      'filename' => 'modContentType/e241ef5c0c53c8687bbf6859b204dd59.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '789b330c59fb3aa9de63b37d33bd01e8',
      'native_key' => 4,
      'filename' => 'modContentType/46472ed827245cda27f53281e5f3da72.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '4fe04bc1f557d70efdaafabb95da353a',
      'native_key' => 5,
      'filename' => 'modContentType/becf93ae25b9fa94043ee1e633c3e65b.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e77b3711a389984ea09e8ee53be5c479',
      'native_key' => 6,
      'filename' => 'modContentType/bdd1a10605d098cafaca0cd886cf778a.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '49738a97d48a666d4519cfa0c17f1fa2',
      'native_key' => 7,
      'filename' => 'modContentType/5e01ea96eb08e92df488c1a6aad3e56a.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '38fab642778fac7dacfda5eba7e54ecb',
      'native_key' => 8,
      'filename' => 'modContentType/0004f03e3d60ff5a82826bfe3d9f52ed.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'eb0c77dc6ecc89eff5f11e04c0708cfb',
      'native_key' => NULL,
      'filename' => 'modClassMap/a296e9a4853ef5842051cb80677ff3a0.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '0fac2fa5f6bf6754950a58d33585bc64',
      'native_key' => NULL,
      'filename' => 'modClassMap/f7def95d4781ba7cf7d4dd9b4f02d90b.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f571861718ec35021b1195000b0a91b2',
      'native_key' => NULL,
      'filename' => 'modClassMap/58cdf8fcaf1593cfb88f2f8f70fa6178.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ed7cf74d4e3804c1207614dec9b28ce2',
      'native_key' => NULL,
      'filename' => 'modClassMap/7a54f65ed77410d2903974176f4e706f.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'd0cd7d6c151226d54476c9b5f80a9113',
      'native_key' => NULL,
      'filename' => 'modClassMap/8f18499ce3aa2c3805f9a1d98d761d23.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'abe6533f645ac4204957f1b56fec6d88',
      'native_key' => NULL,
      'filename' => 'modClassMap/d45a677e2f18f00d77788f914524145a.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '117fea2773fba114d3131ae6bde8e492',
      'native_key' => NULL,
      'filename' => 'modClassMap/3120504c674d5bc48ba0167d742a39f7.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'bf939f07f5d2345e5c6a198a2c202812',
      'native_key' => NULL,
      'filename' => 'modClassMap/abb47f7d8ac936c845cc45199f9f5db5.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'cc3865ec2e4fab593709955f4d0c08b6',
      'native_key' => NULL,
      'filename' => 'modClassMap/dd8afbd2841d04a4157c248e822e5712.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c67b0b8ae7b557ecedad1800b035a802',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/7b2f534ae584c2ab56df72713f70c258.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '858ee26ff5e792c757d9c2e80bf0521d',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/9c6d29c6cc742889f14eb344418f0c29.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07e2092be26155e8bc377388ff600caa',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/ab65a3be546e56b5926399ce769f916f.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3dfe0cdb994e60b90cdc53281ca9d90',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/4e01d56bbedd9d486f727751c111155f.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ebef1b483f7474aa0b694522ac888d2d',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/ca18e53623c553dcc5abe270f4674d2a.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47efa2da8d718745bf2172575cca5f3d',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/e0cc287bff8e24cbd02096495c2ebfbb.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65456738240e14ba27ba678b8bbc552d',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/1f6bf3e3e3fdb4d39710fb69ddd1f796.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9423f53ac9319e6696e1adfe9c698b15',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/735483b0308cbc2b693ce469f3cd7c24.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32deff4f14ddc977bb5a8f02fe829555',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/4752cc2960341fcd80272fae5b8f1e5a.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52d94f02cb0a8f664992bef3e44cc3ed',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/75cc720183f22ca9f006c1c51f0358c1.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbd645ecc9fbbff45ae43117d08fa5e3',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/ebf0dec812f940a24d5e0b16b5c99c99.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f7a703d18d5ca85f8730c5b56bb26ce',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/fe6ad9bdb31082df90ea94dcab540a34.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cabc9c2f7a1535ac0adab1821e89155c',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/8e6888393dad73d2aaa3600a708c129c.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '238224e44030d6a80d0cd99608031938',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/b4172b55185325e6d3046d0f43ef9e9d.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9d7349b362b256a4fd5f0174749e43d',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/35bb8abbc146c93d91557eb3f6985166.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6c5e2b4852cad8b0a040ac2e821a740',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/3b98cb96976d2408640de0ca78f7e865.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd29fc2406a0acd4acfc0fbb70c11c8c9',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/6bcbe24330e40d3e7dcdd03015498402.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '597f5559f67219e8a8d246ad0741a9b1',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/6b2de5578131eb3b9a4c72fb635a1164.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '609e54519f73f39cb88bfb65242b276c',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/8413d97c352dfa5ee2509cb3dbf0c5bb.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0eefb99d08639889ad3e788998f32f7b',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/79b597527272e352dfdc6cc814099111.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da91472774f6182d8d53e258eea5b8dc',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/f944e5714237553500484b1980dfc269.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5132e8441113c2e2a283224c792cb0c7',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/7114722eadf77ce7da63fa6239b06bbe.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbb3cca5e436683444715524b2a04a2d',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/fa463587ad70742d77dc4431d053b3b7.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22034aee1e9ea3bb6541d8af0d6ab448',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/a77f87a3ba6ce09a2acb725934b5490c.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3dba98004e9f3c4dd1598ed1579f24e2',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/a5fc9fe70599582bac3d56d8fd7511da.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88066e15edd1a8f18196f4fb9f47966a',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/8cf607523dffef13963d0564b5bb4e00.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca64baf1f2604a3a65d93b8d1d8cbdc7',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/96a76d26b237054749a68bae499e94f3.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5ee01811cf8ebe97c677fcf4bd9ccac4',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/312afda77e74afd9db2b0865184775bd.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '646c7ef96f4fe1c1edbad5543b553f7b',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/6fb5eb0e0b36554dffebf5fe8c510422.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9efe2ac210abfc87f720ca6561e84c8',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/2fdfa9b3e3e95cbe5c8c95bc39364989.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f730162f41f0c3b34ca6315a58ebeda',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/eaae57c948dbfc1ffefa82327a0a6003.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '652e67c613964862979451a8bb989ac9',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/2f625380e1da0a9ee22463bd72e18465.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dcfa218768dda28c339a45bea15f26a8',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/8b82c80067d5dc7ef929e365a074ade1.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69141c939d458aa4caca6e65001b52cf',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/b068ffcb527d60f2bba626e44bd80648.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b23ef7b6f63e837332fce507fe2d1fc',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/dcf9bc2bc940cd7f76fb877db05574ed.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08c7bffe0fe01f2cdffa6c88532cdc8c',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/7e042178a0bbb2f942c036514efd2127.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb4e7f3e4f57460318b7d37b4b319edc',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/76b1d8fa44da7da4f58e186dd662148c.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d9efa475ede69d1003df6762d4446a2',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/e9f0a1d211dc05f21177acc38494620c.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8f3d7878211171746145f6ca8ad19f8',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/c9dfae17ab42eba58e6585f5123e35e4.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4eeb1d253ca3a1f61ce698397628e927',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/27888a8cf10866a4e3d5d8babd35126a.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08cdb161fe007297c3b3f3a7433b9f52',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/e5b31b0e6dfcf3e3c01029191c983ca9.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29b68fe0a5dbff51b57dfddedc38411d',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/5d0075b184a8295e700ff1c1f25bec64.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6033dd26d92455acc137a3d01d03ea06',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/1be2bdb85c2310e6fcbbdfd6d297c0c3.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa2e1d2a2e233f5c05fe50d4460aaa89',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/14a20ff1fff3417621263a5294b00d57.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f207e4c8a17b55cd34fe8f5a9284885',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/bfe9c17a810c850cd878f3d256c0368f.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '750c2e14d6312b0b78431e780780c25e',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/c355fe93dc8ef247e4d662ca7088840a.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0a21cd9c1d315456047394d08e3e925',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/be0429e5bd0615b1472a652e425cc7fb.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4bafd809b2743fd403d83fca21ecbc2f',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/ac8ba55bbf0f2377586893415e2aef77.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc43f979b7a37796b8dc49b9fa6cc6b0',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/2009a40bf0c14fd1a22ddbc307d0cf40.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36fa6e00f8dcc351cb205f13fa97d3db',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/2574c023f0122e5c27963e446ab67ac5.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6b09fcf6f755380773d70bcafb99740',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/d8f48c8eb6187c91327eaf2d7f7062cb.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fbe299a8fcd7730f9a0d58768c4b49d',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/497751cab07d591c78151fb6281cfec8.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f4623aad7a035b715b210234cb992a3',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/6bab23a42dd17cfae029e02b5e33433e.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8f611f193a08354ccaab55830cf53de',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/f8893a1c5475ff26e3862c9d06c2c3bc.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ac1468de15434570f91c3d7765752e7',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/9ebe46934edff63adee2a0ae2d0cdb5d.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '531940584c7d84eefd46ab7ed62799ef',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/685a520a4ba88412a2226d37e93b4db9.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7bcd8f1d1dcc82ad1bbf67fe5b8b1f77',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/c4a9f727234c6dbb530af02872226263.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7dc1c2a81810b2bd4b75243758c6f95',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/84603e4699dc1f87ca85fdd7276d6444.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0be4f89597b3a45aca91b51e0af9fe11',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/b53a9d08a0365322a0347ddf165e2f60.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7949787ecbfa24da8ab448103585c70c',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/e1966a4ff1fe3d3ef778e8c2b80cfa9a.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b4f506c1f1c8c0a92c25635e630b2f9',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/19b69481e262d8757bd10a5197398438.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe9c3a8fe6829f293677049c28863f13',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/47ef92fc168d9d0c17c8b9352f5b776f.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab1acccdf9e9f2940989e628b2fc2f2b',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/0ba8a21e2aa705edbb0ceb89f5b7eb69.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16e971bcdbce7348679ef8c86800b16b',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/c601c1a6c1f89dc12394b7de5af8dace.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2bc8d3143aafa06dea866ebe31ca7b2f',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/b8ee5996c840921bce9b499331ae4452.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1444ba407034dbfc5805bea9b3ae1d90',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/440b4772cbcbbdc8568c2a4e3301a556.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71d2d242c634460f5fbc4252042a9d19',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/eae1894303be60bc94228a70d08e917a.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab580c2424c11bb9a5642739684c6948',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/9a3ed1df5c0fe6f0c564d7f6491b974b.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '876f22cad3d442cfdbbbeb0c5d0c4543',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/3d149129f9453ba0a6923ff531c7b73c.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6abf4b3151c5ee296be3b6f1f5bd1509',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/40e999e794108a628f148b1f5c6f4771.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fcf68c11755c4753a1b5f9f9d43a6156',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/8d678e844ba77699dd02ab00fb1aa385.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eff736142dfbc649dbf37795ed4ba4bd',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/81bf035bd5a420dd61c636eca3f58859.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7b97e16a88be3b2e71c5868bc1d1aa2',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/f0ef3e9dc44250404575aaf2afd3caf6.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a43bf5a7ff0f7089bc55620c0ac47104',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/095f67bc1ac370c99ce55c76e57121ff.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2fb188c253188a4201d2226309c43774',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/3071716fe642cc7cd6f54e7292aa0b2b.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f093293be58704acf0e034f1a327a31',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/19598e7fb93c1865447231f2608b1625.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95108c1c26f38083302cd99e0f955111',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/f40fe41f65acba07b705fdaedb9de5cc.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08632247bf7d95cb8fcafb4b7974d9d8',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/22727b2bd653395a1fa760ef23102a3d.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4d89521cd862292f4948166d8cb6c47',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/5b963007b66a52fc60c63db8a76d13f0.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8a3f53ed6e2a2dcbe2d36acc8f129d9',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/0f2ae7e107a4858bf50384179563afbd.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff8cc7023ab307b0ab2cacab24ee4459',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/7af4b8abc9114f1a06ccbbb54544daa5.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38901cbfe2a5a290c1b1b9c5781ff8b8',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/606ad8735af4e6feec44915bef044962.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d0cb07b2bd6a0d7dacbed847cde687a',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/512fe65bcef3aa74f872236d59dabc28.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c9ef298ca3321d8a3d37b7b86192edd',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/3157d584eeef70c780f5aa69f39ea1f5.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae4b59f72b7803e41094c04a157ab613',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/7b13ae596a62f024a5f052f6dcd448f3.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '756ab72ac2c613a4875eb90df44bff70',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/cdc4f34696d6296f93a891ce6e6beb1e.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3100c4801edf2aaba84d5e14f0b3a966',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/c957c9a39fee5a9dc40fab5e83949e54.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c08ff1b5cce79e46cb06c6e9f9ebe5b',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/d7cdf6fbdebd3709f63ad20e9eb7ed68.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29d8158190850f0db6f2ff3799275b5e',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/263970ff71c3a7897d98c0ff842f6711.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd42bc4e541f2a6582fc010c0f00f84af',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/49ffa40f81ca32ca7f522f036940166d.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f374f69209e0c94726f67c644058caf4',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/d35a91a4b9358e3ec590a587495dbb6b.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9dd3331415da0a7dd91c80152bd0579',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/e9bba1b45a9d15a84452948246f7d33e.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac00976fba5cbd5731960174b283ae30',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/e19cad1cd82a29e5093901e7aff91d32.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ec79a3050061fddccae9d3e9f16ea0d',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/8dbe98ca68932ba176b161d27988b0c5.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '913c52ff494033dd8041f6735d12d93b',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/56168558de81c0863198cf1aa0b93773.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e70b851d1ff3b213c7254285e50719dc',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/5b26c5b4f033e16a10a0402c71d1bcb8.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e74745f0446efd5af937bdb983c50db',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/f7d5aed6bc7bbe5220973084a33e8ab5.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42301df187a65db1708606de04126d2d',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/110f40685bb76ab09220240495384755.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4386bc16c6f62d3838a53a78b969d166',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/35fd5be042cb8bda0f3c1776698f3193.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21c23c5d00fe69663f5d16748466bf6b',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/90edcc1ff9ac3da83d02669d61f6e6ba.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cec8f43e30ae4fc2b669459619275031',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/ac77fa0dccf41ea8e28d3119a2d42a1d.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '783eae01bbf6d31ca0b650e587c31761',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/4a56f3f5420982959ad2cfbfa87eaf3a.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abc4e05184dc6737b3398a3adab57087',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/15b68944b42eb8df50d1505499da65d4.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6017603574c5006a99ac54da7229eac',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/d405fe7f35d06e04a07d121745134a7a.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd75bd6d1f990912cf35c05856100828d',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/205108e398cd66e0113ffb677a0e2c08.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71874078d23141dcd13fb70b5262a036',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/1cc5f567f9407157e223bd99b6ac5cd9.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a885f62b6e77ac9351a03af9e7399d0',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/8d2bf6d116b8a2fb9cde013a5ab2bc21.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8ec833879a1ee3ecbe65296fe2c5651',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/1a7ff5a30e000fa3850644fc5afb859f.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ccaadde54446a890018e8d54f97a470',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/769c3501098ab9bc5db79fd378ba873d.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d82005bdaf67c1e6bb51725f662da04',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/05deec1c664c85052365448c384726d9.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0ebcf0858111889d1448de553951367',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/efcf5a4c696cc693bb2bd5dbb13b3e02.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11096eb3c74ccdf22d7edcefce021572',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/4e82f84c4a3b927f32ca92060d7e39c3.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e504c54cb67a0a603d873d0875f8b8bd',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/f25c61bc67071ef84d4aed65f6134770.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'accc527eddb671e36305ac61d0e35c2e',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/a3b5f6e119047058c881d64b812584ce.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'acc23a4897f18abbf2cba4f308b7f031',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'modEvent/44b6494defbc627c20bc1810d10fb1a9.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0235c05f2b932cdf63046e92a2cab71d',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/4123c74722ebd45e8a2bb148d98f04a5.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09584c6043c821d0b674bf5aaac8d180',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/05e47d11bdef1ae084668520490cbc74.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ac43c0c513e8677ef717d991aa27a57',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/5acd99e2b758250f584b49975415b6a7.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38d57427447e293bb1793c68b867c85b',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/8cade15678ad617f57c62dad08811f4b.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ada707b71105032d300a9b975c08bde',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/b7ee3699d6d6ec26e4113c56a496bfa4.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1baa7890241d735f9a2b8e5787758539',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/6f1d3eabf579585e67a5cfe8817743dd.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c69676ff670c1aebf5d303e6392c537e',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/1fdd01e5db9fff826198a57de47139f5.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33841f04215abfd12138c82fd6d045ba',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/39f0c40e7faa3435f4391cced6a6937d.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d8858cc8013a4fbe061a71ed2375d70',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/bb98f68e2fdf041e1fe22a35c7193e9a.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57f0662b83110b1a983386a15773e0ec',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/b646035d9ca4ebec2e2acf1f103804c4.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d8138f4ac3321d72f0b668675c7bceb',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/9252baec81ca0f10a96d6d9ef149081f.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b1097742467b8c320c170e54a91a52c',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/881e5e7440e528f54d7e6f8f02f9e2c4.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b31a0b0f2cbc060ac1c6eef0bc92761a',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/b9054ecd7fae2ac5ba87e5347725907e.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5efcd6cc9edd98f59f5c4377cae1cfa0',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/1e96bcce5b0c02aa3e2713d1d7207da0.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5a4d67a86e17db21b1cf7dacc8ccbcd',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/0bb860c1861330ff47ba5318951123d6.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4d315ae5f499719f13ac47190f2412f',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/30b8260eac78b5bf8e2bbaca1b4fdfb8.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4effb98b263a32241ee3e88a294539c4',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/91ac6ff676a262c6c9d54d367239e133.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64dea4577b421115ffbb3b3a96d25d82',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/9efe9b75f6eecbeb527fb982db15ca5a.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '63233ef6aed4221fc49b0019c7e6a133',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/2fd2fa44c491a58cfa23d74715a30f47.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85cfb1e8bf810fc02f6c5d2f35b31802',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/372bea098ef38de91f36e1119ac96813.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '109e1cb6d288523452237ea3f2b35a5f',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/3a457a1cde674b6de55bc37d57f95204.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91375310af539032da0c9306365bd150',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/6fa355fcbcf1439f9e2eb2fa337f7b4e.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28374ba16f5f4e7eb4be34deb7a88e65',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/2382d94b3e271bb72a59f2da7ef67981.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76db253d7dc8f4a70b8afe3516275afa',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/5c3c64713375e9bf7a58bc3cc792ea8a.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'badd1278341a5b09653f3d3f5fa11e2d',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/b7a3a0a2fe75f4c5a07ed3262c5acf1b.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33f13b1299a239fd2084cb9ecb073c54',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/1fcad69fb5b79e15f1661b1e3f28ba23.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd240f5989bc02cd09e0ac025def1e3c3',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/d441121c86b9e5b187fccdc4e1db2277.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db5a9183b031ae770c5de3cca6db4aa0',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/80626f789cde6d32fb77c20e650b495d.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ded4d9b6ca4a56859d0d58ac6c647224',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/5dc7cb0bd313b1a729a71bb256ec197b.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff70516828c25d522037207a14a1d1e8',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/e1ea96dacdcb9e52e9d1842081071236.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d94ba4a38e8297ce7bc938c47975066',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/a9a77e88a30f08144605341da616b9fb.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5fb36945be29289491a2a78abd3bddf',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/1b41e3a9133d24815ef56bf885c3dd18.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc501aade84d3ed749b96a669d19f729',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/6512bdf7f999885c196b993e889933ee.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b351198da961f6ecc80c36683f672e8',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/ef77179184c5dc2abd6ad079cf3ec7f6.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f4c096461b4eb448ba4d4d4337ee8ae',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/df7a54814f323b1f003076da06c5ecdd.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad5967586c504e5276ce7a7d3ac0fbb8',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/81102aa7e49b6b096884b00670f4adf2.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '882de10533b31a7d8d9bc709e093b597',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/b1bd1b1a6b40406aca48988a1fb0c8a3.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7917895d827f7955b35e52fd643b30b5',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/d3fe1d19c65ed2315689a92f8d5d5cb3.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2fff9dc052657d83b9b2136dc64706a',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/3ef787fc99caa5552faa179e976c3041.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83a033bd9a1a984b005f5b7e441164ed',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/b97e7f3b53b99d1e4eecea99f7050b19.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0918bfdb8baf8bb2febf3c90c3bc1e23',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/1f5109ff0ecdbedc675a6b61b47db977.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ef17ae260e198130763825c432d61e0',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/7fbb5947c8ed39b996f3f82dc22f700e.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99ded4f7cfe65c058bda2bc43b9d4289',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/526eaf8bfb813975cf17cf3fb5f7d8ac.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c39203464d17a2b9a3009c6ccf9721e1',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/2e232662471f8e257e59e4fbe5fcd24c.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2dc1f7206e8ba8db1d9f3f8376dcd031',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/32da067584cdb715843f49a17c94e5c2.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce44040631b2bd0f06c30db3f967b26a',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/52dd916d61d8ffe2a271ae50bf0cea2f.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f56fc267e1f818d6ace422f9775db1a3',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/96e9cab5d647977a7256188bb22fd3de.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '447d83535dcba9da651e98e9548e0686',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/5ceeec2abd1e5731b2629750b235ad36.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f6320c7923340c5597c9ca9db92ffa1',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/9e67187d6b765af20e3b4cc58e5c618c.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29695c90734a2fa1fe04f3c00e5a872f',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/ca00c0a38cb767794f0dcaa5abb00bfa.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cc385ccef8d7f2150b5a3954e54532ff',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/b27cdba5a7d07a03bcc1d5e1693433e9.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a105cab1e2f0e90ac9ecf539678b9338',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/954be1ecc4ec1b94b9251311e11722b7.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05acbcf93cceec43566e6d7e19e3c1c7',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/7f4d9145a70da7923510a91f4e4017f2.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05e13d63209dfbfa8b09d27486340583',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/560cf86ae158fa4be59583b02868695f.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb6d0c1b18ddef92d07f3f6b56ca6a6f',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/b93c05bd199caa24345bd2c2e3606525.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '109bfc21bded4c053ab60b1c98b53b2d',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/8cf870f1012fb0a0e4f0217da8557f40.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '239ef215f6f73b83390bff594ba1bcaa',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/8e1cfdeff052162f0798e6bd32edd9d8.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b5930ce2cac250dc26088ddd238d89dd',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/6a66608f0f01c2713923e06fe294caac.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55ee881aaf0279bfb071f4b15376b43e',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/f25f6d9b37beea6edf06d71555db1643.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ecee3ef2eabad875cfd9eaf805a2e20f',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/b94bf75ba3eefabe94994b0274c13a1f.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e596fa0246bbf30d261ff6241d11159',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/7610177995bc6b52f2857b0cf6085eb6.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8842a6943b8a444fa433a3455b93028d',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/b04b29a192065823b59c653dd8ac5587.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a218a33978a527df30a2ab7edb6e4eda',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/de2e5774bfe4dd42d31ef70ff7ac6120.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '374af5bba8627b05990a3ffa0c34b30a',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/b2359136816fa9d72d721c2d5a05de70.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8313157eeb71eead3114d98feaf2c62b',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/8784e7b7ea5f2587d86931eb7dfd3ed2.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a629891feaf236a02f371cb25e148656',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/fa9200d72f1d43b5f4199e2896494563.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '554204172b705ca520bbae819d199b4b',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/66096a60077518f86e21d02ec1e5d0a1.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09a87cc389793911223cb203b868f642',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/37e4bfff75f2760679fe4fae0133c3d3.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da5f1bf1c461897f578f204a2e1cf476',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/264486fb13872ff4b4550ea119c011ff.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a5f3bfc2f6428b4863d406da96da90f',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/026ea83b632859139d3288d7b9b57b58.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e95dff614544745e28b401f592950ae',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/1c716555e69d167a8da68adf0b9dd7a5.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '187c265f5c7e63eff53959ab0777a34e',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/3bc68efc07e593c4a3f72843e010b08a.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b42dcd45d8f54f40f8b9be19a6aa6f46',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/7cdec0e8bbcee57f3031fbf7fad8e06b.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14562df1a0e5d4ed6164f9b634ebbc0d',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/14c960f482d2f3773cffcfa3ae3c90ac.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3b98e034e713ef3204c30e4fda974a5',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/b2ec6148346a8527e0699416353a64d8.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11040556f96ea8890c170a9337a68e54',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/7283940bcb9b45ddb2778f8916028545.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1810baf55b6bcf59f2a5e47dc49df3c3',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/0ea89283eb48a29da4edde90b0783272.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0e13ca219b3681dcfe73dbb34bfdab8',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/b0f52064c65e53157971c7b00fb7c699.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50c0b45faf6206de917368d14da33c66',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/326dc407d0ff6859aa6733fc01a03172.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c77f636bba13617149798dab3e1e3db7',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/8a869b27c38f606c10ca6005bbac2cb5.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4f7fffdf9bfd013b553b86331801a58',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/67352252418fbb10b02e93c8b7b616fd.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9303d985d09c25df3e1fb2cf17006f5',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/7d0ace2bc69105b9229066cc6718c065.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c93689b55e95b736850254683a6a5f58',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/8c84ad5c473ee51ef4dd3f27b5501ddc.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7688c564dc6052540901019dd40fc63a',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/7c0a915191deea714c3c0c9ffe674a46.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bce21ad589610e9f542b8269b5ffae8a',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/a2b9cb7f818cd2bfd8f8d2543c49a08f.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11da20c5ec5034f7cadfa4333d8d5c6f',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/3f36cecf90272b2c78bb42220a69557a.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5c705b0a25830826b3864e08118853a',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/c6f5f6eecf7813080cbedbb1a34e7266.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '642ba2ad1e74b19d6d18f54d85826159',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'modSystemSetting/b24a9fd6042c0c56b13070f3382f9a8c.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b546e06aa4bf1362d1f8f1302fb19674',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/44af815c9a974812af4169db4a385184.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b5ff3760dba0ff79058d32697a4fe77',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/ddbd305d6e5da55383387d19a076946e.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f24adb87d09209062ead2d54abfcc9f',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/494979d69be67d990ce569c7e3f5a1ce.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7a06725eff6b857dd6f6df492d79c54',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/a8b5825feddc1cde6217c81a5fcf15d1.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c37ce647709d2a652fef82cb7643770',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/8ed4ac05f8c77d3af10d804f7041600f.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51756f4068eee7a37beafe474d630fce',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/f2898f832e349c2f0e6ffe2f20d3b7b3.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87fb5b947e44cf98a2714386e9b2f32d',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/39f8a2275671928a4ccd5b5a95814a5a.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2b1720ae5b38525c7787c93a581b7c3',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/72ecdc98fda7bb7de4491020481a146c.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd7e92500bf7a79e357444e7e264275d',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/afdaaff23b936839c44b1300bbecb5ce.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7574995cca5460f4db3975daba67194',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/c9fadc4792a397b9c7ad7379271354bf.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f2bd5029d2af237c65c4a7540334c28',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/5ed64889585abc3ecdab647bf470e57d.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35d5648beeca4f47522e5fe13fcfe4fa',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/b269cc393a715740e507905c9c21a6c4.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '700518a1152c32e601ac2f6a36877618',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/279fd3596f622e92158b646213b5fbfe.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '401bd7fe8b125fb8cf0cd34721ad920e',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/e598827aa79a622e5f0ab2133597eeeb.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11d885b0a0579f22a2e9dfb1e5c7f601',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/3e9facf28d615348ce2c734b0b672ce5.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7ab8c867783015e888fd4f3ca5466ba',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/6d3e0bc044041652bbb8920a3ce35e96.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c38f60f9a35a443d07211163fa57b62c',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/0f3b4169adad0477d5bb355756b6837d.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '142de3983a50029325761e7ab0ea151b',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/8e076446c67715bbb1ca5d98b830a239.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9eccad7f76de8aaaacb29b49f661d7a7',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/47701f755d70ba2cfd027dc101962035.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bd8ba83eb17799301032b96a854f660',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'modSystemSetting/27f2a53d40741303d4b537028783b7ec.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '569d68bdb2a5fbc468db47020da809a4',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/5b063670d6969e1f518de86d47954a48.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '525fb85ae81f4afc5a6aefa91f42902e',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/630bda59773a9042d2c77593f22fd08f.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6a3d2ac9186c3c31d86d89b5b6531af',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/17086c387d280eb7cd4d5827e3d437ac.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '742a14cf0fb37a4b2a957cb4d99d1c0a',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/effc9b8afa8388ca1f9c4e1557d04ad9.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecc5ce0cdee5bbb673e360458df7ff34',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/3abfb3acdff18e45d4e0cbb8cb285815.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60d1a8503702a2c1ff6ffd2ec12e570e',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/318010f4913cd26f22aa7ae73d72be51.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ce7bc29a287fc815b07085b6de816f8',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/51bfa27077ec68d128cdefd771385ef9.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '510fe0bcf75654b9b0cda082c2ad118c',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/cfe8cd5126e88b765a9d791adb676856.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd504feb9484d35c86ec9e682e0c43c0d',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/3f2dc226e54fdde81e0217fd59d9e656.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '811e2a7cac18e3f210825c1b84fff413',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/165b2416181b7191226cc32cebc898fb.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce4a743c8baabe16254c011c3df503a5',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/4daf86831561835a5bf4b35a9d271dd2.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a247ace3216898ba682b698f174a3b3',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/926287f7127e0e4e45a75321cc70d468.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3c5765ff4181b86a838dc505b52b4c0',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/023abb7316dd770ba4cd052d79a17e37.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68a92ad5189cae505a6467c83adcc07c',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/ee3027bb365e32c0db13930ef78eb0bd.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '377e2ff30252aa837b7dfcc3b07c5032',
      'native_key' => 'default_media_source_type',
      'filename' => 'modSystemSetting/dc0b694627c4830f70e56f909c5d29b5.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79e51751346cb534c4849c3d559011f4',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/7d04cbbe9ff315bccf0d85fbbc3fdc11.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2baf02504b238aecb7740ec15fc974e5',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/bab2835dfc2f95b84eee56dfb58cf6c8.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5df8d35f620c2386e4a96b746949d5c',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/9a998b78f28b40de45d8ff0fedbeff3a.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cc57840561ea2257f13d31dc6ebd4f0',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/20d6cfc744c2a8836d7b05f9928dc7a7.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb84dec1c8ef590f9a696d566e7fe0aa',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/9a68bd9163ab78f4d0871442d4c6cd62.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a790294bdd37a21bd3890cb14a91992a',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/6122d75fb4dbdf23cebeb04694bc34ed.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d13d9151ddb315f4fa6ebdbb4871c8d',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/410a8433aa98e1ab213522be2d8257d9.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0835259a4def1681f6f52d768686edc9',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/ed76c246c637e3706d07e9980623f6ec.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c023eba939692b3377a36934ce36a4c3',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/391df627ea3dcad0ec2a8a58b12672c7.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16acb0e3b9b82386ab4cb257f96e456b',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/9a1a33131881219931c20a62c8a3ad65.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7543ce56d9f7aba5fd395521592ec4eb',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/4d5153277442cb36f137c2a5d859619f.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc218bd0d1b4db63bf3d31d1040b7e7e',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/6e8110487342ee9acf2cf032c4da7d77.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a54990c35de80262057bf321d09083e1',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/a14e681569ab35320285cdc6aebe969d.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a37eeaab76204464799f406eacb8815f',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/417c5733a87da431c04b288298075c38.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f79ef3e88c81dc2219138aee5ef1727',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/db10000c28875e325cef73d9e8e9e911.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b62afde41f80deebd560c5559422af11',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/2c456c34b0fbe0e1515654168f707d50.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89d26b4894038646b73c3fc6a44aeb83',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/fc72aebe240529503f29ee3a8b1bbbcc.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3456ae682591ef59b34e96ac7c398412',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/86d363eae08c398966244e7915ddd825.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71e9501145f9537a2ac0a611720e3683',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/9bfafa9f153223158a700d5125e5741f.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df026d9d5cd69bb1036715c1656f21e4',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/0ae5d3b70b4728be094961856e9dacf9.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1fa987173bd2c2e1bcffee21348e385',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/91ecb46c738bd152fdc5564ac4c8e554.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bdf00ac26146b19d6586b81949aa5f0',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/7750294d1a551557e4091f38a5daeb87.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38b6e6af80fa627acdc81a48a8db113f',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/1c26ee22b8fa35682ca49888f1c34a34.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '823e5f1308b9eca9b60aa8085a071c82',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/48caf226aaf39878d9a9011c6bfe35fc.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '369a9a8023fb14176b7cd920913025f1',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/7ea91c9cdddffeb12310e9966fd78d2e.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc25ce81c425334cd671795a84eab370',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/141ac552a038940c34588ac2fbcd4dbf.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbf19024d3eadd62781ef945f75facdc',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/e526d023076486bdd5a9400d07f41474.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e0df8e820de4d8c0b2273acbe0126a0',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/44a377f8e1600bebb0f2391965fee25f.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af4de4f3df46ddda5119ebc13535884d',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/d98828efe783c1c631b1a4a1d49dcb99.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57b8addaa6d7a058ec5b8fed34230786',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/3161855c28c1f75832805ed1bde16052.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a10b0af12b1ff384d2240b6c33858d5a',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/bd31da27c91dbbe52e4310ef31c19d95.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e063f790057c591001a80490308d1a76',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/60af32481d879b77e5c1db2c4332b164.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a489bf352138400c75cced29243be6d1',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/c87942eb020b865ca61904e200f60419.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f03dd62b8a6a2c38a8f1b3de29a8f98c',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/4852680db6b430755d5015341fe4521e.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80eb69fda5b576e9eb3889c652ada53d',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/510093fa5ac0007b9309f74c01443c8e.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0318b0012169f4d5c05036ebbdb45fcd',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/fa389af3664098a861d1b45b2f7b29a4.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca64d67c817a108bbbd506501eb45f02',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/2045b0850231933c9efd1759ae09360c.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12d92af6ea2c27928d1987efff560453',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/c7bd2c098af7e64f51752fba5ebda76d.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14d9b265b61e48816233f55026b5ed69',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/0ff6df5bd41dc05748fba89c42f56b40.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '273bee8ba9bbf6f3b3bb67cea31edd13',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/7cebc67b56fce67d4b057938de4eaa47.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62a854fad7de8c639bbab321be4ee14b',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/b68dd83e0940b2931f143de72fefdb87.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '696ff9578652264ab3c08068f6ca43c6',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/f3f1af32e0ac13730d825ad2b3bd08a2.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '734deb3d259391443b4f6036310b14b5',
      'native_key' => 'log_deprecated',
      'filename' => 'modSystemSetting/8dfeae473f0833d13ec3bf5620b05ce2.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c12888e35faf01bbef38d76e18bae74',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/d0c3bb6e938f431052c44239bf95320b.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2faaabc16ece8a6f701a371992eda5b',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/becc3df0d556a91e6e9bb2ed69e330d1.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa487ee091e2c9f463edd27a96d10f1e',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/a5123b29376ddfba3dcbde7b1ea8478b.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5480c88e433dd967be21da882a8f5c97',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/3426c1f7367d5886ec095e4fb9b7808c.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ff066fd7a213e70cc40be75188b5992',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/0a04b455bf9a585319e6d5c9be16ec21.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '733a8f9dad3b08f1846743001630ea62',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/2572ccff8cd4a1479128d71978d7a8ac.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '328ae79c066090da2da9d4f3a1f71fa7',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/3fd858b7f9ab86d48d03f99187241a4c.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7886700a3ad63a2050661d9a288d6930',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/d07f00f8b971e897b74685c6bbb63180.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e419b813097d14e69f64c2db2db7102d',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/b6b9228f2d83aeca81cbaf5c83aba390.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce2ba3e2efa1b1dd443ed5d292033513',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/e67a1a70009f84351c9423df2c4f8a14.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e831abf4ea21ef49442cc730b407e6c8',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/b3fcfd478cc60d184cc1a17564ad1732.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83be1c48f94ed2dd0b2a7d192400b5b7',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/546fbccb1340a001c2d84b3b29b30375.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0386797f588c09b963fd020af3d832ba',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/9cceb10a29b73afdb84ed09a5000db84.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c36fc178ee74e3eae311cecf70b14e3',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/8e4a8ac99f9971a8a886d16a00f92255.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56465482a7f8c970ae114bcb80bcc153',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/8e5284dd08e52729ad70e1d59bb09187.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6a2cb1771cf1099d66e2ab5e63ceabf',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/44e86e1d577bedd79565e5b0ff6b2da4.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a82a6f8677f5233c6e69cacaf4e43a4c',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/2264c40b2a9d91b3c6b424a4f07dcc10.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef6e07f3fbc4111b7dd4aff8e664ccba',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/93933502164d27119465f9d9bcd8deb7.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fcdf95809e9ff2b3a82ca79308400cc',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/9011f72927798d39da136a897cf9a837.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1491d773bae4a095ca0f03d6ec584feb',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/35d0c89bb1061c8c9e2756c5ecf2ecd5.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b094b858a3d630ebb052212dfe9a505',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/a6c49562bf1348db8e44953f13f75478.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1d2c7c739d53c1f7fd36d60c69fe67d',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/c8c4051ce839230728e85dd71a0653af.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d7c3658cd60b1f2a8a3006466d7b208',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/bb24fb5f5aad1757e8efd7d640e7cbbb.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '228502f58795c39ee7a6a8b699571950',
      'native_key' => 'login_background_image',
      'filename' => 'modSystemSetting/bcf1967e84938fb1bc988075ddb52c28.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd27f5f0548556ef23de002e8383d0a06',
      'native_key' => 'login_logo',
      'filename' => 'modSystemSetting/2d2a7b488830f6a952bf3d3cdb5445d8.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f334e085811db22d997b0a4a6f0c0914',
      'native_key' => 'login_help_button',
      'filename' => 'modSystemSetting/e4c22d68d4b199f9addabcdda0084424.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9db0b340f58dc7e5150133bc56c45d62',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/63bb6ccd4365a94d66b466689ed181d9.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a47bdde982fdacbda879796f3612430f',
      'native_key' => 'manager_logo',
      'filename' => 'modSystemSetting/d86d50e5844b1c04a9b90e4b452e5c68.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '087ed4ddb158155eb2ba5b383cdc1ad7',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/2eefa90f3147d0bce2b6087bcd977b46.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b6aaac26d0f55172e614bb45e103192',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/7171d81a2395e18501aec121fa1aa113.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78837c36ae9ca7aaa3906993bf34b26f',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/e85868141dc19953a0d4bbdd916f5926.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67884cc7557c6dec6a5673b5ab776827',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/c3007f460d39a447dedf8013f84d1692.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49ab5aa70d353b8894522341245350f8',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/d31c589c66259a3941c1613c2f32d305.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '172379ada736388b89502ebee65922cc',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/3ed666277a4cdda5a42beefa5f9bf796.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51000ebc85d25346d91b9dcb57f344f4',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/a70516215201cbbe1b7c7cbe377298f0.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52bec879918bd737d4ad15f0b05f3690',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/b73317c325828ebd2ef54be27c41d8b9.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b27bfae7bb424350e1498ab6ba32c572',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/a19eb9a69492e0d563fa44dc665538c6.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '895f7ba80cc851413beec543363dabab',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/9170afcf89dddd4f0201140349f69068.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8908e37bf522ae0daada391e5aaf38ee',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/564966ec6edddfddd73529c29ccc358f.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3dc8da1c528f5d8b409a5c1fe6d7508a',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/fe9c16be9751fad4ed704dce6b2edb27.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b31e097b6c7576eafac8843b2b06ccb',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/aee3ea0445e169f9c6e6abcfd4ce87f0.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9862f0b9f12a4bbcaae9c53ef214aa08',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/da0c5f96857191ebd79d3bd878f8bb8e.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70bba1908f567b60db90c2f2d24718a6',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/cef93a383201ceac5eccb1c30f20104c.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25e414b2f530db7fb67ad41ff5272606',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/e92cbba9a6d922ccbebacb21207d133c.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c81db7dd10bcfcb86bf2ebd251d2561',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/b195326c2478c57f1565c50446ccf5dd.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56ff51959c1a344c8a5d5e96271c9504',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/31d8cc20af67eefbcdf7b552b8f8f1ac.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd2857ae2ff74b2cba219594aa84de09',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/40162baef82364c633cccfc0fa03f806.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31e718a025a0a02498b48e18df8e322a',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/1da426717c3beaa7cade087cbf0e94f4.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ede6be73e072a28093e4924c0e442ba3',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/d114fb17ebae4516fa13713ab51b2afd.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '406bfe1bad7093e7d4423f72bc4f3933',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/f3e697deeb98cc80d1f31a1cbfca34fc.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0ff9b3fa0c3f068ce7e433a6ce6cca7',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/c0a7ef3ee62a794ea8f456d0ee8d2241.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4733112a5aec806bc7d8b88db22c5947',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/6a26d7aee34b60626b0412443f5779c1.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ff01a42cd9f725c09c151249afc469c',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/1319b582bb29b640afbf943a8c4b0ecd.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '046d96c0dfaf9e35397714f577ca7e89',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/41fa65ea7720b8bb241fd91cd2db874f.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b9e896626780ac381362ff2a191e082',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/281cad6526b1a17724b9fe88d9a42c01.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15620f282eecc3993d8e07300fc5a1f3',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/210ba4f04d7d4bc7bc194483d8a3f5e7.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '003f9ae68d4d8d91bdcb6579932c947b',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/319d3bcdb1338e0b5fdf5059790c3355.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e100541620bcb3488ab2720c814a357a',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/ed4188a18269f23cf7f57e9b0cbe9b66.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e0dbb5b6507eaf0a58860c8ba951c76',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/1cb291f19508a5926fdc5cd4f1e9b942.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43cd843a2946906ce49ebe82cf8eefdf',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/3e43eae58a53b19ac910188346efbf61.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24d85ae9ae28edcd4f066bd8a4dc11c7',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/b350eaa1f4d17bfaf50dff26f45b735d.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c845b972af16b8c3074fccb24e5b2d10',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/ac53f54c473feac71d72e1ef7822248c.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7757e209ea54f4dca1816957be7fae8',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/b1758927c085a14b5d6341d6faaf266a.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d65367a4a0e9f0376311543b786d890',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/735ac0c701e9c3cf773b65deddcf2848.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd90c4082e5a4bfa2b620d22340f06400',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/1959b223df288cbec388428981c9630d.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ae67bfcf95d82feb04ba39319710d96',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/7ec725f7604ff0b7b650e50f5ee4524a.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63b6e8e96073b6be4836c2e6938ef73f',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/5521811d6d5c5b0219ebf003176865d7.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c3f73cf14a30fad5844366c9551f407',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/61f0ee25abe435fb75a66733587cca59.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e8747b3e34538f2c48d8e22d953e58e',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/358fc59dc0e60635b608e450433904e6.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d60c168b21df76da31f413c8e3e341a',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/2b6f571636db09721d3239a5e7bc0253.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3c8fd84fb0329eda7c22d43d391ad4a',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/8b8dc0b0a7054df69d9ccab4f5465e47.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb54da409586887fed76f6c8dfaa36d5',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/700653ae0c4b311dd7990612a4739808.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52a5d3089bf5739b0990c9febad7e8f6',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/93e1738cd75d016786b2df71a47be8de.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc5f35e8ca8cd639be4820d7cd61c0d9',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/04d7f91c2e09e648d3aa15bf1cbcd848.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92d71da568e1d3b84d2879ca9110e925',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/bdae8a5cb7d6c00a504b026e197c2599.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59e0b63b0cecf7b712f1c1cb168cd3d1',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/1204f93458b0648950e7f2a82c9341c5.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a87607e83ea64c322bc69a5cf7ca0dda',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/012b3f32b487ebed7a58202250ea29f9.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31086d7feb1fe971e89e75015b542463',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/0230aba269e00c0dfa163f52b7b7a3b1.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d1265ed62aa002d2ea22424d2fc12d0',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/7b22edd26f4eaff7be28dc065229ef09.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cd1ef2373f89564aaf2ddb6e8ea541d',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/1d564b9e27935bfe1d5c9a4cdb949749.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f57cf3dc6ba563942b9c69ecd289e08a',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/14bb989c1dca1216c813a327f3c4fce3.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ef9cad52fcae6a63548c9cf1a67fe8f',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/c54b221600332c51ddb4eeeb419446a2.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bb564db0ad675253865d31789e1b2c5',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/3c7015d32d889fcdfee9e0737615c447.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3434c4af42732a5ad7c3636945ee4676',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/236334072e11f946663777864ae65502.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45b6eb241d80ad6b35c58ee403947561',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/6002ac1fa3b251734e4af7c01732c3c3.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18a56a9f12368847356faf4a5be7e48b',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/e6dc8f1f41abf938f7b7e3c75c44aa65.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5676a4ffe7787e9fc7a42a22aa59f60d',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/b9b03fed262aeac6f904bf4391ab333c.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f1fd23cb10a585c92a6b0ee6bf27394',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/e1da2a40dbefe33eb0dfbaf7febb1a4c.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8be16530a2646ce39d05afc773b110cd',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/6bd95d4f0453878b62b9d694211ffba5.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fb7a3a34547d3633871fa2a8052b7f0',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/1339ba41ff47c4ee530f7b70033fe366.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3412e5bbfc4e4f567bc310bd222b276',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/90ef100a42e5d62f53fadcf7f2839ffa.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '858ab48d5c753737b082d96bd4f3f108',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/8524ded762e16c2cd49f024b214fb1fc.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae6b1d37690911acdc9b879ce39ea27f',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/eb07b336ba8229c30d4ed3463b55a6cb.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '381d454f2d4df52d696e059595158cf2',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/57a2e693cfd8b1f471004712a86a1286.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e953efa8da7a5aa00a717eaafb02fd64',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/73cabf9edd099cd2427f37f240294f2f.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75ac0babf6fb9e5911c6b74560d3f630',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/243842894fdd3d392401be49db56c7ed.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f10bb0646c627c04c184c4bd346a5935',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/17694d2fcb098a4d782a5d39f936cc43.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5e85cb7171820a821328bfb4ae63773',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'modSystemSetting/1b993762e502bd8ad7e24bc1c2fc5912.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f69bd0afba5b90780c8bef62ed2e3c04',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'modSystemSetting/4433a9d3b03b85896d715de4584f3d30.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebe986583c69ee7ffa29bc32fa75051b',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'modSystemSetting/67e91536e8a05042bf0f6ef8a5bdafed.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39e1c4f168d297ee8cdbbbc015f98196',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'modSystemSetting/bc0aebedfdc6d1ba1c7eb41e56b35996.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e724f675546571c0b9b4e70efbbfdbe9',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'modSystemSetting/f90ab98d6c2220d0301f7fc3d8aa67a6.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3ecd39195973618442ce2b648c536ec',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'modSystemSetting/c7b29796149755632dcd769c553f932d.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6186a6041ce6d35710163fb27126fc87',
      'native_key' => 'static_elements_default_category',
      'filename' => 'modSystemSetting/5b5d4ee2725f77a2046e6d83571b6f4d.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24da11f22de208e7d65ba572ba46c00b',
      'native_key' => 'static_elements_basepath',
      'filename' => 'modSystemSetting/230ab630a3e44281c36f8ab02b9dbade.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54e6d815ddf9d5d28d065ad1d26f9fc0',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/8a8a85e68e087b99021a27969900abfb.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '207714ed740654447be7091ee84d44f5',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/117cef8a6014f45f795d747757c00ee1.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c976512e14ccceb5b45bdc247cb0c54d',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/957add69041a88384d2d9db34d199b43.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89c2f20feefd619df0c92bc4391758f3',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/49aa30e322ff76d21550aafe13f85df7.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1387124ed6e254752dc6fd2f7cf2e9a1',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/8de531d7bb12822712a3838db3820716.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91094d0060ce330896912286e640f8aa',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/b009bf7934fa845b16fe05e82c7e3892.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4c051004d42ede42fb9e7b686e08ace',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/45b4aade017e6b2e1ca473ef09958aef.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7b415861fef452fd2695b6ff2c93940',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/f00d2d2616a7766908dd08eac11f8501.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbe1be5118884c496957a6992a78bcc4',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/c7b9b64ed2692a9cb81ad923803c8f83.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b85d0b6c3536350a7720522ef48e7d3',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/92f5b387f5692d8c28b02ce265f99e18.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6cdcc73bb4c4bd7d2c47b9f33c4c070',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/c107871bbf01b2a299028585503928f3.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cc315f357287705350f7789e52284ce',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/1b79e8fd0256f5dceb426e56fa5f2fb2.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a42d285fb3219c2257723c011309575e',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/35d8fcc5048861ea60b47cbd57377c88.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b77b47bf7f3686718d589635e820f78',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/26b92aa784643ea81232a0e651b6bc3e.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1839ca03f946558c0a2c1c1ad9560efe',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/3b1d26ec2c5c6d1284ed47da848890fc.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25c5e7ecfaff2f3dd5f9b83cfa16f29a',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/8602dc8a14bdea65ee26e5da98c2ff6d.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a448e90143b65a7f5797bba55aa8f20e',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/077e5ca000d63db13aadf45a0e8cdc9c.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afa18c06ea6da440de7df3f523943212',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/96f936e79d271e00ca39218c2b13b138.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be79145025d353398d6eaebf0af08099',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/59c5ce106be2aff7693eb364aff4dd19.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90cb4c84b2df37b2b03100e9229092b3',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/015fd2a3b4f1243054e35a8732237240.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46d4f2a4ce63fb2a617102210a34aa0a',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/93dac0e402788c8c523b0479d48154a8.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39855ec2081f5b7acbed3a5257ec0ad3',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/f468065e775ec6b9bbd49b7a34cf9320.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a8e62222496e031970dc73461fa487b',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/4308bb5f61862e2f4aac8c1b3844f1ec.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '734223a6f2ea8162b39cc5a7227add86',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/488d7dddff37452866b5f0a09416cd04.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93365ca40ed1e94814e32d23dbc5459e',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/6310e551be648b479b24fe8b2fbc1922.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd263aefecf1a8b46e50fb6acc9c14eb5',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/ea961f7e324cbe026137bb89488d3e64.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c08aa6ccf44af84381769b882feb7d43',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/7dfe66d846d63595e85c244c9df5a53a.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67bd53aa99b6cbe595dcbc57044fd775',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/99328f618c97ff3bbbac6b0266467265.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae980f5824cdb3626279eff7bfc0a120',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/0336c9d4c0360e1db5b142f31f374ee2.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '529b1fa9b3e6d3b8c640872761562b52',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/43a7b441b9a65f17d9881a861100428a.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '305948479af5fc0de06447329ca86ef1',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/d3e53fe66e339ab5916ff469644c654f.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47866bdfcb8b9f1cfda8cebc49c7e0d4',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/6ed087ef49f1ec72f982d019c94496e5.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12d84957883e6d6f149cb537b81951c2',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/26007af1329d4057736b72e64884eff6.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f7db5e2d77594e205b36ac528c35b42',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/780c4158a876132035153de983435335.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc86d637b00019d1ddd72bfa43c984d5',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/245ca575546e4160da7596c0f86e4aff.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1541019fa293c4612fbbd9511a9078bd',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/25f307555c8ba58cd2c145dfe001ce14.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a956a7c52c4d906583549b949c00bd7',
      'native_key' => 'error_log_filename',
      'filename' => 'modSystemSetting/eed4d979f06e0771053d67f28e0ba540.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0681a5922b7c508a4d1f87e9a3a53e46',
      'native_key' => 'error_log_filepath',
      'filename' => 'modSystemSetting/6c952046f20d5dc15f5151b8f4d2fe93.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b52afbe2337a78fbb8767a9f922f823',
      'native_key' => 'widget_welcome_background',
      'filename' => 'modSystemSetting/9093550e04032dc83a907b4b38edecd8.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '8dd9b1c334e7a3ce6ab8fe7c68d12882',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/553f3ae2770daa727ccb4f88e171fca9.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'f00acb8a55d41fc479eda6ad54c6d44a',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/4b958b688e0f07414a83c3d20eef1c42.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '5c70f0a872baa9b3df072815aa2a611f',
      'native_key' => 1,
      'filename' => 'modUserGroup/7719dc1320fa7fd9c78157bf85477caf.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '94b3bb0129b3b0eab2ae962b5f432201',
      'native_key' => 1,
      'filename' => 'modDashboard/fc5be47b4c83a6ece0197b8474b05c20.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'c4ce068e5c782236ee2dfc4a1984bfb7',
      'native_key' => 1,
      'filename' => 'modMediaSource/120dd0cc7df03dcd61e9fdcce50c6a18.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'd560f730859501cb4f2f165ebd9af489',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/4f55a4fa4d9c89010ddec2840d47f5e0.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '94133325374626acc7f533d00a50078d',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/22a0eca2d208b8ba86f0d5ceb419b706.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '2b8fdb5b01c09dee34825920cca7bc08',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/c47b1eaf520d531f7387706475cae593.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '6a57f9f94841f512d5afc7b8e8a16f5a',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/da53bd2cf2d2c24040f4984566e45510.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '7ff9a6e760bedd724f1cbe8a2fbddbef',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/2530ae712c58f6595decbf3b5b87bc46.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '360b480d2d8ecf7224fc4e4ee30926bd',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/d2051edd323903f13e19fc83e0479b66.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'b8df2812fbd35c61028a0d84534c867a',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/c248682616a83da07586ac4990486981.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '8ba584ff2d1caf19dc1c47c96b5c27e7',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/c07880fd71a70fbc57a9e12e4848b292.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '046fe315abbd376f097ff8267bcdc7bf',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/90fdc02ee8058645186cc000be62065c.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '81182ff932d36adcb21c433b2f85ac9b',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/39967f70e9dab824cd1debdf88bd1f4a.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'd28d65c489197ef4fef788c2aa1cceec',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/242addc823bb9537c7bda504478f1ab5.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'd791b5a1f651178688129b8c45fc4cd1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/4d6f95717aded2c3afc7a0dd93a48699.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '12477de8f212c9c5dc8b96a8da940efb',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/f9088a9107c41b09d786728dca5f4e53.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '9d408964665914408de7c5ac9d7e1df0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/2e65e4ef83025a78304404d35cb518f5.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'a858e9aa6c8447338396e727e26b02c0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/94d20124a8df097a6b234a00cc1aa781.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7e7ba09ed71c54c9e40199f53d8ff07f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/e8e0298a88eba0822fca338320041e10.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '4b6081a8973929687979b256a890b3b4',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/41a02aa29743477032018a1f7cb9bbe4.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '4a1692be90a4c545320458cf686edb33',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/3cec949f46bd1f5f2a1b317f36b7cf06.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '8c3e45e3cad360de8124286d63319dd5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/dbe217f392fbdbf6dcace13bf503ef3d.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '31c4885901b2ec9f36ac74ed2682fe1f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/5976efdc52f9a754f6c2b47203c27c26.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '798c3ccfb40514466359eadb99a2ef24',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/5f399703572f4ba5cd39a8be14c53be7.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '919d6a8c5dd2825c2a14b8449e764531',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/94199db34b5c13f91a64e2e67dd64a56.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '7bab51b0c3b9942c75507bbb85151f3b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/4038d480ae093c5c073d13a76fa30bb0.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '2e80486a96da42df361958d5e03bae06',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/a0ca2c82083f675bfce050ad095ca7f3.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0cb1906c5508b924c5eaea01d9b20930',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/1c09537398a0abd7ce141e593a6edd9c.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '66f4fcbd6d4aab56358f6a24229b4143',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/af0f503a53f7b2f470a95fbb38d088ca.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6e707f403d6dfc8710e552eff5794f5a',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/6d4486891a8ecfb0c44338026f1ad7cf.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e323e0bea27ed0f02907371eb974c061',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/20a19b3c05238b90a219971413eb186a.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ad55482d86a26ffd935a1d36a46ea539',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/6b2d3ff38210c851c2e5e36906485193.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5be2a2827d9c6642b4407935578a0c78',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/3ad7f93d5c2d0c530f0ed65e2868c2f6.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b8d4d54c62d5c086738862e40a7ad33a',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/ba630b86bb4eef4c8b855cf19db0eace.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '97568dc0df241cda29b003c6462834d1',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/8a3f4e66a69055b36bf100836fd8c057.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b96bcf331dfb85236539ef7bdb7b6c51',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/29dd787cc503967222b8d2c5d6d4c4c7.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a6697641a63c8f0acaf775b1903cadcc',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/efb978ddd4ba92499751273ee8576ec8.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f0f952b198b016dc892b68f8d566ae18',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/a353306cf2b63b5bec46a9fbeffb0190.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '60b7866d48440241e2077b6a88b76e5b',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/261fa43268adb0c35e22471fa4da4aec.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'e537501c5688fa239b08a51933713144',
      'native_key' => 'web',
      'filename' => 'modContext/4c41a88781be2a75d2b057094674ddfa.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'd867b95efcea3d0fcab38620aeeaebb8',
      'native_key' => 'mgr',
      'filename' => 'modContext/24b3fe18f025ef404ceedb912b0cc217.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '4c85d951b549b098290d8e55936228ad',
      'native_key' => '4c85d951b549b098290d8e55936228ad',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/07ac26268ce115074829953789b64be7.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '59154571391c29a9f6a870a45fe81ba3',
      'native_key' => '59154571391c29a9f6a870a45fe81ba3',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/24c466016b8dbbac8064b680f71e28f9.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '1a983ff095400a5c354279ccde6e2575',
      'native_key' => '1a983ff095400a5c354279ccde6e2575',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/1e7aca798331b5558b54b3fe04a85b4a.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'cffa27157875ed056855e70b21fa7bf9',
      'native_key' => 'cffa27157875ed056855e70b21fa7bf9',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/15301e9df54b3e788375a72c5faa4850.vehicle',
    ),
  ),
);