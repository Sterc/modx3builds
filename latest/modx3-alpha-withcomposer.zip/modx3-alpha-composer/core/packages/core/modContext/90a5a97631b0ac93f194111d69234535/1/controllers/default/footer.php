<?php
/**
 * Loads the footer
 *
 * @package modx
 * @subpackage manager.controllers
 */

$this->setPlaceholder('_search', (int)$modx->hasPermission('search'));